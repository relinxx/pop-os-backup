import requests
from bs4 import BeautifulSoup
import time
import re
from urllib.parse import urljoin, urlparse
import csv
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException, StaleElementReferenceException
from datetime import datetime
from DatabaseFunction import DatabaseFunction, get_sites_id
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
import pandas as pd

# Get the current date and time
current_datetime = datetime.now()
f_datetime = current_datetime.strftime("%Y-%m-%d %H:%M:%S")
#print("Scraping Started at :",f_datetime)

def load_more():
    try:
        while True:
            load_more_button = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.XPATH, '//div[@class="row loadMore text-center"]/div/a[contains(text(), "+ Visa fler")]'))
            )
            load_more_button.click()
            time.sleep(1)
    except StaleElementReferenceException:
        print("Button is no longer clickable. Stopping.")
    except Exception as e:
        print(f"Error: {e}")

def cookie_button():
    try:
        wait = WebDriverWait(driver, 10)
        button_xpath = '//*[@id="onetrust-accept-btn-handler"]'
        popup_button = wait.until(EC.element_to_be_clickable((By.XPATH, button_xpath)))
        if popup_button:
            popup_button.click()
    except TimeoutException:
        print("Popup did not appear within the specified timeout.")
    except Exception as e:
        print(f"Error handling modal: {e}")

def discount_button():
    try:
        wait = WebDriverWait(driver, 5)
        text_to_check = "Kampanjer just nu - upp till 30% rabatt"
        button_xpath = '//*[@id="__next"]/div[2]/div/div/button'
        
        # Wait for the text to be present in the page
        wait.until(EC.text_to_be_present_in_element((By.CSS_SELECTOR, ".MuiTypography-footnote"), text_to_check))
        
        # Once text is present, click the button
        popup_button = wait.until(EC.element_to_be_clickable((By.XPATH, button_xpath)))
        if popup_button:
            popup_button.click()
    except TimeoutException:
        print("Text or button did not appear within the specified timeout.")
    except Exception as e:
        print(f"Error handling modal: {e}")

def extract_size(product_name):
    # Define regular expressions for different size patterns
    size_patterns = [
        r'(?i)\b(?:Vit|Grå|Black|White)\b\s*(\d+\s*[a-zA-Z]+[-\s]*[a-zA-Z]*)$',  
        r'(\d+\s*[a-zA-Z]+[-\s]*[a-zA-Z]*)$',  
        r'([a-zA-Z]+[-\s]*\d+[-\s]*[a-zA-Z]*)$',  
    ]
    
    # Try to find a matching size pattern in the product name
    for pattern in size_patterns:
        match = re.search(pattern, product_name)
        if match:
            return match.group(1).strip()
        
    # Return None if no size pattern is found
    return None

def scrape_price(response):
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Check for Kampanjpris
    kampanjpris_price = get_price_for_label(soup, 'Kampanjpris')
    
    if kampanjpris_price:
        return kampanjpris_price
    
    # Check for Klubbpris
    klubpris_price = get_price_for_label(soup, 'Klubbpris')
    
    if klubpris_price:
        return klubpris_price
    
    if not kampanjpris_price or klubpris_price:
        webbpris_price = get_price_for_label(soup, 'Webbpris')
        return webbpris_price


def get_price_for_label(soup, label):
    # Find the element with the specified label
    label_element = soup.find('p', string=label)
    
    if label_element:
        # Get the sibling span containing the price
        price_element = label_element.find_next('span', class_='MuiTypography-root')
        if price_element:
            return price_element.string.strip()
    return None

# Set up ChromeOptions
chrome_options = webdriver.ChromeOptions()

# Add headless mode
# chrome_options.add_argument("--headless")

# Set custom user agent
user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
chrome_options.add_argument(f"user-agent={user_agent}")

# Adding driver logs 'chrome.log'
#service_args = ["--verbose", "--log-path=chrome.log"]
#chrome_options.add_argument("--enable-logging")
#chrome_options.add_argument("--disable-disk-cache")
#chrome_options.add_argument("--disable-memory-cache")
#chrome_options.add_argument("--disk-cache-dir=null")
#chrome_options.add_argument("--media-cache-size=0")
#chrome_options.add_argument("--disk-cache-size=0")
#chrome_options.add_argument("--disable-offline-load-stale-cache")
#chrome_options.add_argument("--disable-application-cache")
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--disable-extensions")
#chrome_options.add_argument("--disable-gpu")
#chrome_options.add_argument("--disable-software-rasterizer")
#chrome_options.add_argument("--disable-dev-shm-usage")
chrome_options.add_argument("--start-maximized")

prefs = {
    "profile.default_content_setting_values.images": 2,
    "profile.managed_default_content_settings.javascript": 2,
    "disk-cache-size": 4096
}

#chrome_options.add_experimental_option("prefs", prefs)

# Create Chrome webdriver instance with the specified options
#driver = webdriver.Chrome(options=chrome_options, service_args=service_args)
driver = webdriver.Chrome(options=chrome_options)
print(type(driver))

# Initialize variables
product_cards_data = []
Brand_Links = []
product_cards_filename = 'apotekhjartat.csv'
unique_links = set()  # Initialize unique links set

# Check if the product_cards.csv file exists
if os.path.exists(product_cards_filename):
    print(f"{product_cards_filename} already exists. Using existing product_links.")
    
else:
    # product_cards.csv file does not exist, continue with brand_card and product_card collection
    print(f"{product_cards_filename} does not exist. Starting brand_card and product_card collection.")
    Base_URL = "https://www.apotekhjartat.se/"
    brand_cards = "https://www.apotekhjartat.se/varumarken/"
    response = requests.get(brand_cards)
    soup = BeautifulSoup(response.content, 'html.parser')
    brand_elements = soup.select('.brandpage--list__item li a')
    
    if brand_elements:
        # Extract and print the href attribute of each link
        for brand_element in brand_elements:
            link = brand_element.get('href')
            
            if link is not None:
                full_link = urljoin(Base_URL, link)
                Brand_Links.append(full_link)
                
    else:
        print("no links")
        
    print(len(brand_elements))
    print(len(Brand_Links))


    # Initialize variables
    item_id_counter = 1
    #num_iterations = 50  # Number of iterations before restarting the driver
    batch_size = 10  # Number of brand links to process before restarting the driver
    processed_links = set()

    cookie_clicked = False  # Flag to track if the cookie button has been clicked in the current loop break

    for i, brand in enumerate(Brand_Links):
        # Restart the driver after processing every batch_size brand links
        if i > 0 and i % batch_size == 0:
            driver.quit()
            os.system("taskkill /f /im chrome.exe")
            driver = webdriver.Chrome(options=chrome_options)
            cookie_clicked = False  # Reset the flag after restarting the driver

        # Skip processing if the brand link has already been processed
        if brand in processed_links:
            continue

        try:
            driver.get(brand)
            if not cookie_clicked:
                cookie_button()
                cookie_clicked = True  # Set the flag to True after clicking the button
            load_more()
            page_source = driver.page_source

            # Use BeautifulSoup to parse the HTML
            soup = BeautifulSoup(page_source, 'html.parser')

            # Find all <a> tags with class "gmt-click"
            a_tags = soup.find_all('a', class_='gmt-click')

            # Extract and print href attributes
            counter = 1
            for a_tag in a_tags:
                href = a_tag['href']

                if href not in unique_links:  # Check if link is unique
                    print(f"{counter}. {href}")  # Print with counter
                    product_cards_data.append([href])
                    unique_links.add(href)  # Add to set of unique links
                    counter += 1  # Increment counter


            # Add the processed brand link to the set
            processed_links.add(brand)

        except Exception as e:
            print(f"Error processing brand link {brand}: {e}")

    # Save product cards to a CSV file after processing all brand links
    with open(product_cards_filename, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerows(product_cards_data)
    print(f"Product cards saved to {product_cards_filename}")


#for index, product_link in enumerate(product_links[start_index:], start=start_index):

# Read existing product_links from product_cards.csv
with open(product_cards_filename, 'r', newline='', encoding='utf-8') as csvfile:
    reader = csv.reader(csvfile)
    next(reader)  # Skip the header row
    
    # Load unique links into a set
    product_links = set(row[0] for row in reader if row)

product_links = list(product_links)

# Initialize variables
item_id_counter = 1
#start_index = product_links.index('https://www.apotekhjartat.se/produkt/desloratadine-sandoz-filmdragerad-tablett-5-mg-30-st/')
start_item_id_counter = item_id_counter
num_iterations = 50  # Number of iterations before restarting the driver

driver.quit()

#for index, product_link in enumerate(product_links[start_index:], start=start_index):
#while start_index < len(product_links):
for product_link in product_links:
    try:
        # Make a GET request with the specified user agent
        response = requests.get(product_link, headers={"User-Agent": user_agent})

        # Check the status code
        #print("Status Code:", response.status_code)

        soup = BeautifulSoup(response.text, 'lxml')

        # (1) Product Name
        product_name = soup.find('h1', class_='MuiTypography-root MuiTypography-h1 css-1yzuyz7').text.strip()
        print('product_name:',product_name)

        # (2) Price
        price = scrape_price(response)
        if price:
            price = price.replace(":-", "").replace(":", ".").strip() + " Kr"
            print("(3) Price:", price)
        else:
            print("(3) Price not found.")

        # (3) Description
        description_heading_element = soup.find('h3', string='Detaljerad produktbeskrivning')
        if description_heading_element:
            product_description_element = description_heading_element.find_next('span')
            if product_description_element:
                product_description = product_description_element.get_text(strip=True)
            else:
                product_description = 'N/A'
        else:
            product_description = 'N/A'
        print("Description",product_description)

        # (4) EAN
        ean_element = soup.find('h3', string='EAN')
        if ean_element:
            ean_number_element = ean_element.find_next('span')
            if ean_number_element:
                ean_number = ean_number_element.get_text(strip=True)
            else:
                ean_number = 'N/A'
        else:
            ean_number = 'N/A'
        #print(ean_number)
        #if ean_element:
            #ean_number = ean_element.text.strip()
        if len(ean_number) >= 12 and ean_number[0] == '0':
            ean_number = ean_number[1:]  # Remove the leading '0'
            #print("Adjusted EAN Number:", ean_number)
        print("EAN Number:", ean_number)


        # Load the category assignment CSV file
        category_assignment_df = pd.read_csv('category_assignments.csv')

        # (5) Categories
        categories_element = soup.find('h3', string='Kategori')
        if categories_element:
            category_elements = categories_element.find_next('div').select('a')
            categories_list = [category.text.strip() for category in category_elements]
        else:
            categories_list = []

        # Initialize a set for unique parent categories
        parent_categories_set = set()

        # Iterate over the categories
        for category_name in categories_list:
            # Check if the category name exists in the CSV file
            if category_name in category_assignment_df['CategoryName'].values:
                # Get the parent category value for the matched category name
                parent_category = category_assignment_df.loc[
                    category_assignment_df['CategoryName'] == category_name, 'ParentCategory'].iloc[0]
                # Add the parent category to the set
                parent_categories_set.add(parent_category)

        # Convert the set to a list for the unique parent categories
        unique_parent_categories = list(parent_categories_set)

        # Print the categories and unique parent categories for demonstration
        print(f'categories: {categories_list}')
        print(f'Unique parent categories: {unique_parent_categories}')


        # (6) Brand
        brand_element = soup.find('h3', string='Varumärken')
        if brand_element:
            brand_link = brand_element.find_next('div').find('a')
            if brand_link:
                brand = brand_link.text.strip()
            else:
                brand = 'N/A'
        else:
            brand = 'N/A'
        print("Brand:", brand)
        
        # (7) Image Links
        image_elements = soup.find_all('img')
        image_urls = [img['src'] for img in image_elements if 'www.w3.org' not in img['src']]

        # Print only the external scraped image URLs
        for i, url in enumerate(image_urls, 1):
            parsed_url = urlparse(url)
            if parsed_url.netloc:  # Check if it's an absolute URL
                print(f"Image URL {i}: {url}")
                
        #(8) Apotekets varuid
        apotekets_varuid_element = soup.find('h3', string='Apotekets varuid').find_next('span', class_='MuiListItemText-primary')
        if apotekets_varuid_element:
            apotekets_varuid_number = apotekets_varuid_element.get_text(strip=True)
            print("(8) Apotekets varuid Number:", apotekets_varuid_number)
        else:
            print("Apotekets varuid element not found.")
            apotekets_varuid_number = "N/A"  # Set a default value if element not found
            
        #(9) link
        print('link:',product_link)


        productName = product_name
        productsubtitle = apotekets_varuid_number
        productprice = price
        ProductBrand = brand
        product_description = product_description
        product_instructions = ""
        category_name_list = unique_parent_categories
        image_list = image_urls
        productEAN = ean_number
        Size = ''
        rating = ''
        sites_id = get_sites_id(product_link)
        link= product_link
        formatted_datetime = f_datetime

        print("------------")  # Separator between products
        # Convert the list of category names to a string, separated by a delimiter (e.g., comma)
        category_names_str = ', '.join(category_name_list)
        print(category_names_str)
        # Insert or update information into the MySQL database using DatabaseFunction
        DDB = DatabaseFunction()
        DDB.insertion(
        productName, productsubtitle, productprice, ProductBrand,
        product_description, product_instructions, category_name_list,
        image_list, productEAN, Size, rating, sites_id,
        formatted_datetime, link)

    except Exception as e:
        # Handle any errors that occur during processing
        print(f"Error processing product link {product_link}: {e}")
        continue  # Continue to the next iteration of the loop

