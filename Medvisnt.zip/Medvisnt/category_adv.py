import csv
from fuzzywuzzy import fuzz
from nltk.corpus import wordnet
import nltk
import chardet

#nltk.download('wordnet')

# Function to find synonyms of a word
def find_synonyms(word):
    synonyms = set()
    for syn in wordnet.synsets(word):
        for lemma in syn.lemmas():
            synonyms.add(lemma.name())
    return synonyms

# Function to find best match for each category considering synonyms
def find_best_match_with_synonyms(category, main_categories_swedish, main_categories_english):
    # Initialize variables for best match and score
    best_match = None
    highest_score = -1
    
    # Find synonyms of the category
    category_synonyms = find_synonyms(category)
    
    # Iterate through all main categories
    for main_category_swedish, main_category_english in zip(main_categories_swedish, main_categories_english):
        # Calculate fuzzy match score with Swedish category
        score_swedish = fuzz.partial_ratio(category.lower(), main_category_swedish.lower())
        
        # Calculate fuzzy match score with English category
        score_english = fuzz.partial_ratio(category.lower(), main_category_english.lower())
        
        # Check if any synonyms of the category match either the Swedish or English main category
        for synonym in category_synonyms:
            synonym_score_swedish = fuzz.partial_ratio(synonym.lower(), main_category_swedish.lower())
            synonym_score_english = fuzz.partial_ratio(synonym.lower(), main_category_english.lower())
            if synonym_score_swedish > score_swedish:
                score_swedish = synonym_score_swedish
            if synonym_score_english > score_english:
                score_english = synonym_score_english
        
        # Update best match if score is higher
        if score_swedish > highest_score or score_english > highest_score:
            highest_score = max(score_swedish, score_english)
            best_match = main_category_swedish if score_swedish >= score_english else main_category_english
    
    return best_match, highest_score


# Main categories to match against (English)
matching_categories_english = [
    "Allergy medicine",
    "Face",
    "Child & Parent",
    "Dermatological Skin Care",
    "Animal",
    "Electronics",
    "Fever & Aches",
    "Home & Cleaning Products",
    "Aids & Accessories",
    "Cold",
    "Skin",
    "Hair",
    "Hands & Feet",
    "Intimate care",
    "Stomach & Intestine",
    "Food",
    "Mouth & Teeth",
    "Professional Beauty",
    "Wounds, bites and stings",
    "Sex & Lust",
    "Stop smoking",
    "Makeup & Makeup",
    "Sunscreen",
    "Vitamins & Dietary Supplements",
    "Exercise & Weight",
    "Eyes & Ears"
]

# Allergimedicin, Ansikte, Barn & FÃ¶rÃ¤lder, Dermatologisk, HudvÃ¥rd Djur, Elektronik, Feber & VÃ¤rk, Hem & StÃ¤dprodukter, HjÃ¤lpmedel & TillbehÃ¶r, 
# FÃ¶rkylning, Hud, HÃ¥r, HÃ¤nder & FÃ¶tter, IntimvÃ¥rd, Mage & Tarm, Mat & Dryck, Mun & TÃ¤nder, Professionell SkÃ¶nhet, SÃ¥r, bett och stick, Sex & Lust,
# Sluta rÃ¶ka, Smink & Makeup, Solskydd, Vitaminer & Kosttillskott, TrÃ¤ning & Vikt, Ã–gon & Ã–ron
 
# Main categories to match against (Swedish)
matching_categories_swedish = [
    "Allergimedicin",
    "Ansikte",
    "Barn & Förälder",
    "Dermatologisk Hudvård",
    "Djur",
    "Elektronik",
    "Feber & Värk",
    "Hem & Städprodukter",
    "Hjälpmedel & Tillbehör",
    "Förkylning",
    "Hud",
    "Hår",
    "Händer & Fötter",
    "Intimvård",
    "Mage & Tarm",
    "Mat & Dryck",
    "Mun & Tänder",
    "Professionell Skönhet",
    "Sår, bett och stick",
    "Sex & Lust",
    "Sluta röka",
    "Smink & Makeup",
    "Solskydd",
    "Vitaminer & Kosttillskott",
    "Träning & Vikt",
    "Ögon & Öron"
]

# Function to detect file encoding
def detect_encoding(file_path):
    with open(file_path, 'rb') as f:
        rawdata = f.read()
    return chardet.detect(rawdata)['encoding']

# Load categories from CSV
csv_categories = []
encoding = detect_encoding('category.csv')
with open('category.csv', newline='', encoding=encoding) as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        csv_categories.append(row['CategoryName'])

# Dictionary to store matched categories
matched_categories = {}

# Match each category
for category in csv_categories:
    matched_category, score = find_best_match_with_synonyms(category, matching_categories_swedish, matching_categories_english)
    matched_categories[category] = matched_category

# Write matched categories to a new CSV file
with open('matched_categories.csv', 'w', newline='', encoding='UTF-8-SIG') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(['CategoryName', 'ParentCategory'])
    for category, matched_category in matched_categories.items():
        # Check if the matched category is from the English list
        if matched_category in matching_categories_english:
            # Find the index of the matched category in the English list
            matched_index = matching_categories_english.index(matched_category)
            # Use the Swedish list to get the corresponding Swedish parent category
            matched_category_swedish = matching_categories_swedish[matched_index]
            writer.writerow([category, matched_category_swedish])
        else:
            # Use the matched category directly if it's not from the English list
            writer.writerow([category, matched_category])
