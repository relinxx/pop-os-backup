import requests
from bs4 import BeautifulSoup
import time
import re
from urllib.parse import urljoin
import csv
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException, StaleElementReferenceException
from datetime import datetime
from DatabaseFunction import DatabaseFunction

# Get the current date and time
current_datetime = datetime.now()
f_datetime = current_datetime.strftime("%Y-%m-%d %H:%M:%S")
print("Scraping Started at :",f_datetime)


def load_more():
    try:
        while True:
            load_more_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, '//div[@class="row loadMore text-center"]/div/a[contains(text(), "+ Visa fler")]'))
            )
            load_more_button.click()
            time.sleep(5)
    except StaleElementReferenceException:
        print("Button is no longer clickable. Stopping.")
    except Exception as e:
        print(f"Error: {e}")

def cookie_button():
    try:
        wait = WebDriverWait(driver, 2)
        button_xpath = '//*[@id="onetrust-accept-btn-handler"]'
        popup_button = wait.until(EC.element_to_be_clickable((By.XPATH, button_xpath)))
        if popup_button:
            popup_button.click()
    except TimeoutException:
        print("Popup did not appear within the specified timeout.")
    except Exception as e:
        print(f"Error handling modal: {e}")

def extract_size(product_name):
    # Define regular expressions for different size patterns
    size_patterns = [
        r'(?i)\b(?:Vit|Grå|Black|White)\b\s*(\d+\s*[a-zA-Z]+[-\s]*[a-zA-Z]*)$',  
        r'(\d+\s*[a-zA-Z]+[-\s]*[a-zA-Z]*)$',  
        r'([a-zA-Z]+[-\s]*\d+[-\s]*[a-zA-Z]*)$',  
    ]

    # Try to find a matching size pattern in the product name
    for pattern in size_patterns:
        match = re.search(pattern, product_name)
        if match:
            return match.group(1).strip()

    # Return None if no size pattern is found
    return None

# Set up Selenium webdriver with headless mode and a custom user agent
options = webdriver.ChromeOptions()
# options.add_argument("--headless")  # Add headless mode
user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
options.add_argument(f"user-agent={user_agent}")
print("Driver initialized successfully")

#adding driver logs 'chrome.log'
service_args = ["--verbose", "--log-path=chrome.log"]
#driver = webdriver.Chrome(options=options, service_args=service_args)

# Create Chrome webdriver instance with the specified options
driver = webdriver.Chrome(options=options)

product_cards_data = []
Brand_Links = []
product_cards_filename='apotekhjartat.csv'

# Check if the product_cards.csv file exists
if os.path.exists(product_cards_filename):
    print(f"{product_cards_filename} already exists. Using existing product_links.")
    
    # Read existing product_links from product_cards.csv
    with open(product_cards_filename, 'r', newline='', encoding='utf-8') as csvfile:
        reader = csv.reader(csvfile)
        next(reader)  # Skip the header row
        #product_links = [row[0] for row in reader if row]  # Skip empty rows
        product_links = list(set(row[0] for row in reader if row))
        

else:
    # product_cards.csv file does not exist, continue with brand_card and product_card collection
    print(f"{product_cards_filename} does not exist. Starting brand_card and product_card collection.")

    Base_URL = "https://www.apotekhjartat.se/"
    brand_cards = "https://www.apotekhjartat.se/varumarken/"
    response = requests.get(brand_cards)
    soup = BeautifulSoup(response.content, 'html.parser')
    #//*[@id="CybotCookiebotDialogBodyButtonDecline"]

    #Brand_element = soup.select('#mainContentHolder > div:nth-child(3) > div:nth-child(3) > div:nth-child(2)')
    #Brand_element = soup.find('div', id='clubLoginModal')

    brand_elements = soup.select('.brandpage--list__item li a')
    #print(brand_elements)
    if brand_elements:
    # Extract and print the href attribute of each link
        for brand_element in brand_elements:
            
            link = brand_element.get('href')
            #print(link)
            if link is not None:
                full_link = urljoin(Base_URL, link)
                Brand_Links.append(full_link)
                #print(full_link)
    else:
        print("no links")
    print(len(brand_elements))
    print(len(Brand_Links))
    # Print the type of the variable
    print(type(driver))

    for brand in Brand_Links:
        driver.get(brand)
        cookie_button()
        load_more()
        page_source = driver.page_source

        # Use BeautifulSoup to parse the HTML
        soup = BeautifulSoup(page_source, 'html.parser')

        # Find all <a> tags with class "gmt-click"
        a_tags = soup.find_all('a', class_='gmt-click')

        # Extract and print href attributes
        for a_tag in a_tags:
            href = a_tag['href']
            product_cards_data.append([href])
            print(href)
            # Save product cards to a CSV file
    # Save product cards to a CSV file
    if not os.path.exists(product_cards_filename):
        with open(product_cards_filename, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerows(product_cards_data)
        print(f"Product cards saved to {product_cards_filename}")
#link_element = driver.find_element_by_xpath('//*[@id="advice-slider"]/div/ul/li[1]/div/div[2]/h6/a')

item_id_counter=1
start_index = product_links.index('https://www.apoteket.se/produkt/pureness-b-vitamin-60-st-burk-ej-metall-1561493/')
for product_link in product_links[start_index:]:
    try:
        
        rating_text='N/A' # Reset rating_text for each new product
        driver.get(product_link)
        cookie_button()
        
        link=product_link
        time.sleep(3)
        # (1) Item ID
        print(f"(1) Item ID: {item_id_counter}")
        item_id_counter += 1  # Increment the counter for the next item

        main_div = driver.find_element(By.CLASS_NAME, 'MuiPaper-root')

        # (2) product name
        product_name_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, '/html[1]/body[1]/section[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/h1[1]'))
        )

        # Extract and print the text content of the product name element
        if product_name_element:
            product_name = product_name_element.text.strip()
            print("(2) Product Name:", product_name)
        else:
            print("(2) Product name not found.")

        #(3) Size
        size = extract_size(product_name)
        print(f"(3) Size: {size}")

        #(4) Find the price
        price_element = main_div.find_element(By.XPATH, '/html[1]/body[1]/section[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/span[1]')

        # Extract and print the text content of the price element
        if price_element:
            price = price_element.text.strip()
            # Remove ":-", replace ":" with ".", and add " Kr"
            price = price.replace(":-", "").replace(":", ".").strip() + " Kr"
            print("(4)Price:", price)
        else:
            print("(4)Price not found.")
        
        text_data=''
        
        # (5) Description 
        try:
            element = driver.find_element(By.XPATH, '//*[@id="mainContentHolder"]/div[3]/div[1]/div[2]/div/div[2]/div/div/ul/li[1]/div/div/p')
            text_data = element.get_attribute("textContent")  # Use get_attribute to get text content including child elements
            print("(5) Description:", text_data)
        except NoSuchElementException:
            print("(5) Description not found for this product.")

        # (6) EAN
        try:
            ean_element = driver.find_element(By.XPATH, '/html[1]/body[1]/section[1]/div[3]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/ul[1]/li[1]/div[1]/div[1]/div[3]/div[1]/div[3]/div[1]')
            ean_number = ean_element.text.strip()
            print("(6) EAN Number:", ean_number)

            # Check if it's a 13-digit number and starts with '0'
            if len(ean_number) == 13 and ean_number[0] == '0':
                ean_number = ean_number[1:]  # Remove the leading '0'
                print("Adjusted EAN Number:", ean_number)

        except NoSuchElementException:
            print("(6) EAN element not found at the original XPath. Trying alternative XPath.")

            # Try the alternative XPath
            try:
                ean_element_alternative = driver.find_element(By.XPATH, '//*[@id="mainContentHolder"]/div[2]/div[1]/div[2]/div/div[2]/div/div/ul/li[1]/div/div/div[4]/div/div[3]/div')
                ean_number = ean_element_alternative.text.strip()
                print("(6) EAN Number (Alternative):", ean_number)

                # Check if it's a 13-digit number and starts with '0'
                if len(ean_number) == 13 and ean_number[0] == '0':
                    ean_number = ean_number[1:]  # Remove the leading '0'
                    print("(6) Adjusted EAN Number (Alternative):", ean_number)

            except NoSuchElementException:
                print("(6) EAN element not found at the alternative XPath. EAN number not available.")
                ean_number = "N/A"  # Set a default value or handle accordingly


        #(7) categories element
        categories_element_label = driver.find_element(By.XPATH, '//div[@class="ah-facts-list__property"][contains(text(), "Kategori")]')
        categories_element_value = driver.find_element(By.XPATH, '//div[@class="ah-facts-list__value ah-facts-list__valueLink"]')

        # Extract and print the text content of the categories element
        if categories_element_label and categories_element_value:
            categories_links = categories_element_value.find_elements(By.XPATH, './/a')
            categories_list = list(set(link.text.strip() for link in categories_links))
            print("(7) Categories List:", categories_list)
        else:
            print("(7) Categories element not found.")
            
        #(8) brand element
        try:
            brand_element_label = driver.find_element(By.XPATH, '//div[@class="ah-facts-list__property"][contains(text(), "Varumärke")]')
            brand_element_value = driver.find_element(By.XPATH, '//div[@class="ah-facts-list__value"]//a')
            brand_text = brand_element_value.text.strip()
            # Remove leading and trailing spaces
            brand_text = brand_text.strip()
            print("(8) Brand:", brand_text)
        except NoSuchElementException:
            print("(8) Brand element not found.")
            brand_text = "No brand"  # Default value

            
        #(9) Image element
        image_element = driver.find_element(By.XPATH, '/html/body/section[1]/div[3]/div[1]/div[1]/div/div/div[1]/div[1]/div[2]/div/div/ul/li[2]/img')

        if image_element:
            image_url = image_element.get_attribute('src')
            print("(9) Image URL:", image_url)
        else:
            print("(9) Image element not found.")

        #(10) Product features element/Subtitle 
        try:
            product_features_element = WebDriverWait(driver, 5).until(
                EC.visibility_of_element_located((By.XPATH, '//div[@class="col-md-12 jsAboveVariantSelect"]//ul[@class="productMainUSP ng-scope"]'))
            )
            
            product_features_text = product_features_element.text.strip()
            print("(10) Product Features:", product_features_text)
        except TimeoutException:
            print("Timed out waiting for product features element to be visible.")
            product_features_text = 'Product features not found'  # Default value
        except NoSuchElementException:
            print("(10) Product features element not found.")
            product_features_text = 'Product features not found'  # Default value

            
        # (11) For Review Extract HTML after JavaScript execution
        html = driver.page_source

        # Parse the HTML with BeautifulSoup
        soup = BeautifulSoup(html, 'html.parser')

        # Review/Find the div with class 'testfreaks-loaded' and extract the script content
        rating_div = soup.find('div', class_='js-accordion-product-review testfreaks-loaded')

        if rating_div:
            script_content = rating_div.find('script', type='application/ld+json')
            if script_content:
                script_text = script_content.text
                # Extract the rating using regular expression   
                rating_match = re.search(r'"ratingValue":"([^"]+)"', script_text)
                if rating_match:
                    rating_text = rating_match.group(1)
                    print("(11) Rating:", rating_text)
                else:
                    print("(11) Rating value not found in script.")
            else:
                print("(11) No script tag found in the rating div.")
        else:
            print("(11) Rating div not found on the page.")

        print(f'(12) {link}')
        
        productName = product_name
        productsubtitle = product_features_text
        productprice = price
        ProductBrand = brand_text
        product_description = text_data
        product_instructions = ''
        category_name_list = categories_list
        image_list = [image_url]
        productEAN = ean_number
        Size = size
        rating = rating_text
        sites_id = 5
        link= link
        formatted_datetime = f_datetime

        print("-------------------")  # Separator between products
        # Insert or update information into the MySQL database using DatabaseFunction
        DDB = DatabaseFunction()
        DDB.insertion(
        productName, productsubtitle, productprice, ProductBrand,
        product_description, product_instructions, category_name_list,
        image_list, productEAN, Size, rating, sites_id,
        formatted_datetime, link)
        print(f"This product is Added/Updated Successfully: {product_name}")
    except Exception as e:
        print(f"Error processing product link {product_link}: {e}")
        continue  # Continue to the next iteration of the loop
    
driver.quit()
