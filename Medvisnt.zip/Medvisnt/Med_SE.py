from selenium import webdriver
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import time
import requests
import re
from urllib.parse import urljoin
import csv
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from DatabaseFunction import DatabaseFunction, get_sites_id
import os
from datetime import datetime
import pandas as pd

product_cards_filename = 'med_se.csv'

# Get the current date and time
current_datetime = datetime.now()
f_datetime = current_datetime.strftime("%Y-%m-%d %H:%M:%S")
print("Scraping Started at :",f_datetime)

# Set up Selenium webdriver
options = webdriver.ChromeOptions()
options.add_argument("--headless")  # Add headless mode
#options.add_argument("--start-manimized")
user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
options.add_argument(f"user-agent={user_agent}")
print("Driver initialized successfully")

# Create Chrome webdriver instance with the specified options
driver = webdriver.Chrome(options=options)

# Navigate to the starting URL
start_brand_url = 'https://www.meds.se/varumarken/'
print("Navigating to the starting URL:", start_brand_url)
driver.get(start_brand_url)

# Clicking cookie button
def cookie_button():
    try:
        wait = WebDriverWait(driver, 3)
        button_xpath = '//*[@id="onetrust-accept-btn-handler"]'
        popup_button = wait.until(EC.element_to_be_clickable((By.XPATH, button_xpath)))
        if popup_button:
            popup_button.click()
    except TimeoutException:
        print("Popup did not appear within the specified timeout.")
    except Exception as e:
        print(f"Error handling modal: {e}")

cookie_button()

# Initialize a list to store product links
product_links = []
item_id_counter = 1
unique_item_categories = set()
product_cards_data = []

# Check if the product_cards.csv file exists
if os.path.exists(product_cards_filename):
    print(f"{product_cards_filename} already exists. Using existing product_links.")
    
    # Read existing product_links from product_cards.csv
    with open(product_cards_filename, 'r', newline='', encoding='utf-8') as csvfile:
        reader = csv.reader(csvfile)
        next(reader)  # Skip the header row
        product_links = [row[0] for row in reader if row]  # Skip empty rows
else:
    # product_cards.csv file does not exist, continue with brand_card and product_card collection
    print(f"{product_cards_filename} does not exist. Starting brand_card and product_card collection.")
    def load_more():
        try:
            load_more_button = driver.find_element(By.CSS_SELECTOR, 'button[data-action="load-more-items"]')
            load_more_button.click()
            time.sleep(3)  # Add a delay to allow the new items to load
            return True
        except NoSuchElementException:
            return False
    while True:
        # Get the page source
        page_source = driver.page_source
        soup = BeautifulSoup(page_source, 'html.parser')

        # Find all brand cards
        brand_cards = soup.find_all('div', class_='brand-card')
        batch_size = 10  # Number of brand links to process before restarting the driver
        processed_links = set()

        for i, brand_card in enumerate(brand_cards, 1):
            a_tag = brand_card.find('a')
            if a_tag:
                brand_link = 'https://www.meds.se' + a_tag.get('href')
                
                # Skip specific brand link
                if brand_link == 'https://www.meds.se/party-pets/':
                    continue

                # Check if we should start collecting links
                #if brand_link == 'https://www.meds.se/4Living/':
                    #start_collecting_links = True
                start_collecting_links = True
                if start_collecting_links:
                    # Restart the driver after processing every batch_size brand links
                    if i > 0 and i % batch_size == 0:
                        driver.quit()
                        driver = webdriver.Chrome(options=options)

                    driver.get(brand_link)
                    cookie_button()

                    # Wait for the page to load
                    time.sleep(2)
                    while load_more():
                        pass
                    # Initialize an empty set to store unique product links
                    unique_product_links = set()
                    # Find product links within the class "product-card"
                    product_cards = driver.find_elements(By.CLASS_NAME, 'product-card')
                    for product_card in product_cards:
                        product_link_element = product_card.find_element(By.CSS_SELECTOR, 'a[href^="/"]')
                        product_link = product_link_element.get_attribute('href')
                        full_product_link = urljoin('https://www.meds.se', product_link)
                        
                        # Add the product link to the set of unique product links
                        unique_product_links.add(full_product_link)
                        print(full_product_link)
                    # Convert the set of unique product links to a list
                    unique_product_links_list = list(unique_product_links)

                    # Extend the main product cards data list with the list of unique product links
                    product_cards_data.extend([[link] for link in unique_product_links_list])

                    # Add the processed brand link to the set
                    processed_links.add(brand_link)

        # Save product cards to a CSV file
        if not os.path.exists(product_cards_filename):
            with open(product_cards_filename, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerows(product_cards_data)
            print(f"Product cards saved to {product_cards_filename}")

# Filter out invalid URLs (header rows) from product_links
valid_product_links = [link for link in product_links if link.startswith('https://www.meds.se/')]
unique_item_categories = set()
print("Number of product links:", len(product_links))
start_index = product_links.index('https://www.meds.se/sigma-beauty/sigma-beauty-e25-blending') +1
for product_link in valid_product_links[start_index:]:
#for product_link in valid_product_links:
    productName = ""
    productsubtitle = ""
    productprice = ""
    ProductBrand = ""
    description = ""
    product_instructions = ""
    category_name_list = []
    image_list = []
    ean = ''
    Size = ''
    rating = ''
    ProductLink=''
    ean_number=''
    
    cookie_button()
    #time.sleep(2)
    
    
    # Load the category assignment CSV file
    category_assignment_df = pd.read_csv('category_assignments.csv')

    # (11) Size and category extraction using requests
    response = requests.get(product_link)
    soup = BeautifulSoup(response.content, 'html.parser')
    product_overview_div = soup.find('div', class_='product-overview')

    # Check if product_overview_div is None
    if product_overview_div:
        product_info = product_overview_div.find_all('div', class_='info')

        parent_categories = set()  # Set to store parent categories

        for pro_info in product_info:
            title = pro_info.find('div', class_="title").text
            if title == 'Förpackningsstorlek':
                # Check if the size div is present
                size_div = pro_info.find('div', class_="text")
                Size = size_div.text.strip() if size_div else "No size information"
            elif title == 'Kategori':
                category_div = pro_info.find('div', class_="text").find_all('a')
                for category in category_div:
                    name = category.text
                    if name not in category_name_list:
                        category_name_list.append(name)
                        # Check if the category name exists in the CSV file
                        if name in category_assignment_df['CategoryName'].values:
                            # Get the parent category value for the matched category name
                            parent_category = category_assignment_df.loc[
                                category_assignment_df['CategoryName'] == name, 'ParentCategory'].iloc[0]
                            # Add the parent category to the set
                            parent_categories.add(parent_category)

    else:
        # If product_overview_div is None, set Size to indicate no size information
        Size = "No size information"

    print(category_name_list)
    print(Size)
    print(parent_categories)  # Print the set of parent categories
    
    driver.get(product_link)
    page_source = driver.page_source
    soup = BeautifulSoup(page_source, 'html.parser')

    # (1) Item images
    try:
        product_images = soup.find('div', class_='product-images')
        if product_images:
            image_url = product_images.find('img')['src']
            print(f"(1) Item images: {image_url}")
    except:
        print('no image')

    # (2)Find the product name (Item name)
    product_name_element = soup.find('h1', class_='h2')
    if product_name_element:
        item_name = product_name_element.text.strip()
        print(f"(2) Item name: {item_name}")

    # (3) Price
    price_text = ""
    price_div = soup.find('div', class_='prices')

    if price_div:
        # Check if there's an 'active-price' class within 'prices' class
        active_price_div = price_div.find('div', class_='active-price')
        
        if active_price_div:
            # If 'active-price' is present, use it
            price_text = active_price_div.text.strip()
            print(f"(3) Price (discounted): {price_text}")
        else:
            # If 'active-price' is not present, use the 'inactive-price' class
            price_div = soup.find('div', class_='price')
            if price_div:
                price_text = price_div.text.strip()
                print(f"(3) Price: {price_text}")
            else:
                print("(3) Price: No price information")
    else:
        print("(3) Price: No price information")

    # (4) Description
    description_div = soup.find('div', {'class': 'read-more-content line-clamp'})

    # If the first class is not found, try the second class
    if not description_div:
        description_div = soup.find('div', {'class': 'details-content'})

        if description_div:
            description = description_div.text.strip()
            print(f"(4) Description: {description}")
        else:
            print("(4) Description: No description div found")

    # (5) EAN
    ean_div = soup.find('div', class_='title', string=re.compile(r'ean', flags=re.I))
    if ean_div:
        ean = ean_div.find_next('div', class_='text').text.strip()
        print(f"(5) EAN: {ean}")
    else:
        print("(5) EAN: No EAN information")
    # Check if it's a 13-digit number and starts with '0'
    if len(ean) >= 12 and ean[0] == '0':
        ean = ean[1:]  # Remove the leading '0'
        print("Adjusted EAN Number:", ean)

    # (6) Item ID
    print(f"(6) Item ID: {item_id_counter}")
    item_id_counter += 1  # Increment the counter for the next item

    # (7) Brand name
    brand_info = soup.find('div', class_='info')
    if brand_info:
        brand_title = brand_info.find('div', class_='title')
        if brand_title and brand_title.text.strip().lower() == 'varumärke':
            brand_name = brand_info.find('div', class_='text').text.strip()
            print(f"(7) Brand name: {brand_name}")
            # Remove leading and trailing spaces
            brand_name = brand_name.strip()
        else:
            print("(7) Brand name: Not found or unexpected structure")
            brand_name = "No Brand"  # Set to "No Brand" if not found
    else:
        print("(7) Brand name: No brand information")
        brand_name = "No Brand"  # Set to "No Brand" if not found

    # (8) Link
    link=product_link
    print(link)

    productName = item_name
    productsubtitle = ""
    productprice = price_text
    ProductBrand = brand_name
    product_description = description
    product_instructions = ""
    category_name_list = parent_categories
    image_list = [image_url]
    productEAN = ean
    Size = Size
    rating = ''
    sites_id = get_sites_id(link)
    link= link
    formatted_datetime = f_datetime

    print("------------")  # Separator between products
    # Convert the list of category names to a string, separated by a delimiter (e.g., comma)
    category_names_str = ', '.join(category_name_list)
    print(category_names_str)
    # Insert or update information into the MySQL database using DatabaseFunction
    DDB = DatabaseFunction()
    DDB.insertion(
    productName, productsubtitle, productprice, ProductBrand,
    product_description, product_instructions, category_name_list,
    image_list, productEAN, Size, rating, sites_id,
    formatted_datetime, link)
    print(f"This product is Added/Updated Successfully: {item_name}")
#print("Disconnected from MySQL")

print("Unique Item Categories:", unique_item_categories)
# Close the browser when done
driver.quit()
# Print the product links and their length
print("Number of product links:", len(product_links))
#print(product_links)