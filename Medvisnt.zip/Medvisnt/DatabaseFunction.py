import mysql.connector
from slugify import slugify

def get_sites_id(link):
    site_mappings = {
        "meds.se": 1,
        "apohem": 2,
        "kronansapotek": 3,
        "apoteket": 4,
        "apotekhjartat": 5,
        "dozapotek": 6
    }

    site_name = None
    for site in site_mappings:
        if site in link:
            site_name = site
            break

    if site_name is not None:
        sites_id = site_mappings[site_name]
        return sites_id
    else:
        return None

class DatabaseFunction:
    def __init__(self):
        self.DB_Server = "127.0.0.1"
        #self.DB_Server = "135.181.68.196"
        self.DB_user_name = "root"
        self.DB_Password = ""
        #self.DB_Password = "LPS123456"
        self.DB_name = "medvinst_server"

        self.connect_to_database()

    def connect_to_database(self):
        try:
            self.conn = mysql.connector.connect(
                host=self.DB_Server,
                user=self.DB_user_name,
                password=self.DB_Password,
                database=self.DB_name
            )
        except mysql.connector.Error as err:
            print(f"Error: {err}")
            raise

    def close_connection(self):
        if hasattr(self, 'conn') and self.conn.is_connected():
            self.conn.close()

    def execute_query(self, query, values=None):
        try:
            cursor = self.conn.cursor()
            if values:
                cursor.execute(query, values)
            else:
                cursor.execute(query)
            return cursor
        except mysql.connector.Error as err:
            print(f"Error executing query: {err}")
            raise

    def escape_string(self, value):
        return self.conn.converter.escape(value)

    def insertion(self, productName, productsubtitle, productprice, ProductBrand, product_description, product_instructions, category_name_list, image_list, productEAN, Size, rating, sites_id, formatted_datetime, link):
        try:
            if not self.conn.is_connected():
                self.connect_to_database()

            cursor = self.execute_query("START TRANSACTION")

            # Insert  brand information
            brand_Id = self.insert_brand(cursor, ProductBrand)

            # Insert  product categories
            self.insert_categories(cursor, category_name_list, productEAN)

            # Insert product images
            self.insert_product_images(cursor, image_list, productEAN, sites_id)

            # Insert  product information
            self.insert_product(cursor, brand_Id, productName, productsubtitle, productprice, Size, productEAN, product_description, product_instructions, rating,sites_id, formatted_datetime, link)

            self.execute_query("COMMIT")
            print(f"This product is Added/Updated Successfully: {productEAN}")
            return True
        except Exception as e:
            self.execute_query("ROLLBACK")
            print(f"Error: {e}")
            return False
        finally:
            self.close_connection()

    def insert_brand(self, cursor, ProductBrand):
        query = "SELECT * FROM brand WHERE BrandName = %s"
        values = (ProductBrand,)
        cursor.execute(query, values)
        BrandResult = cursor.fetchone()
        if not BrandResult:
            query = "INSERT INTO brand (BrandName, BrandSlug) VALUES (%s, %s)"
            values = (ProductBrand, slugify(ProductBrand))
            cursor.execute(query, values)
            self.conn.commit()
            BrandResult = self.execute_query("SELECT LAST_INSERT_ID()").fetchone()

        return BrandResult[0]

    def insert_categories(self, cursor, category_name_list, productEAN):
        for category in category_name_list:
            query = "SELECT * FROM category WHERE CategoryName = %s"
            values = (category,)
            cursor.execute(query, values)
            CategoryResult = cursor.fetchone()
            if not CategoryResult:
                query = "INSERT INTO category (CategoryName, CategorySlug) VALUES (%s, %s)"
                values = (category, slugify(category))
                cursor.execute(query, values)
                self.conn.commit()
                CategoryResult = self.execute_query("SELECT LAST_INSERT_ID()").fetchone()

            # Insert product-category relationship
            query = "INSERT INTO products_category (productEAN, category_id) VALUES (%s, %s)"
            values = (productEAN, CategoryResult[0])
            cursor.execute(query, values)
            self.conn.commit()

    def insert_product_images(self, cursor, image_list, productEAN, sites_id):
        for image_index in image_list:
            query = "SELECT * FROM products_images WHERE productEAN = %s AND  Image_url = %s"
            values = (productEAN, image_index)
            cursor.execute(query, values)
            Image_result = cursor.fetchone()
            if not Image_result:
                query = "INSERT INTO products_images (productEAN, Image_url, site) VALUES (%s, %s, %s)"
                values = (productEAN, image_index, sites_id)
                cursor.execute(query, values)
                self.conn.commit()


    def insert_product(self, cursor, brand_Id, productName, productsubtitle, productprice, Size, productEAN, product_description, product_instructions, rating,sites_id ,formatted_datetime ,link):
        query = "SELECT * FROM products WHERE productEAN = %s AND site = %s"
        values = (productEAN, sites_id)
        cursor.execute(query, values)
        productResult = cursor.fetchone()
        if not productResult:
            query = "INSERT INTO products (brand_Id, ProductTitle, Productslug, ProductSubTitle, productBasePrice, productsize, productEAN, ProductDescription, ProductInstructions, brandrating, site, currentdate, link) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s ,%s, %s, %s)"
            values = (brand_Id, productName, slugify(productName), productsubtitle, productprice, Size, productEAN, product_description, product_instructions, rating ,sites_id ,formatted_datetime, link,)
            cursor.execute(query, values)
            self.conn.commit()
