import chardet
import csv

with open('category.csv', 'rb') as f:
    rawdata = f.read()
    encoding = chardet.detect(rawdata)['encoding']
    print(encoding)
    
'''# Function to detect file encoding
def detect_encoding(file_path):
    with open(file_path, 'rb') as f:
        rawdata = f.read()
    return chardet.detect(rawdata)['encoding']

# Load categories from CSV
csv_categories = []
encoding = detect_encoding('category.csv')
with open('category.csv', newline='', encoding=encoding) as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        csv_categories.append(row['CategoryName'])
        print(csv_categories)'''