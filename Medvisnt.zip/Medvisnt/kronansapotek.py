from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from bs4 import BeautifulSoup
import time
import re
import csv
from selenium.common.exceptions import StaleElementReferenceException, TimeoutException, NoSuchElementException
import sys
import pandas as pd
from DatabaseFunction import DatabaseFunction, get_sites_id
import os

from datetime import datetime
current_datetime = datetime.now()
formatted_datetime = current_datetime.strftime("%Y-%m-%d %H:%M:%S")

product_cards_filename = 'kronansapotek_links.csv'
if not os.path.exists(product_cards_filename):
    print('Please Wait! Calculating the total number of Products.')
    # Set up Selenium webdriver
    options = webdriver.ChromeOptions()
    options.add_experimental_option('excludeSwitches', ['enable-logging'])
    driver = webdriver.Chrome(options=options)
    BaseURL = 'https://www.kronansapotek.se'
    driver.get(BaseURL + '/Produkter/c/store/')

    # Function to handle the modal if present
    def handle_modal(driver):
        try:
            wait = WebDriverWait(driver, 20)
            modal = wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="kronan-modal-root"]/div/div')))
            if modal:
                body_element = driver.find_element(By.XPATH, '//*[@id="kronan-modal-root"]/div/div/div[1]/div/div[2]/div[2]/button[1]')
                body_element.click()
        except Exception as e:
            print(f"Error handling modal: {e}")

    handle_modal(driver)

    # Fetch total number of products
    total_products = 0
    try:
        page_source = driver.page_source
        soup = BeautifulSoup(page_source, 'html.parser')

        pagination_div = soup.find('div', class_='sc-1kt7t3i-0 eiyOEf')
        pagination_p = pagination_div.find('p')
        text_content = pagination_p.text
        numbers = [int(num) for num in re.findall(r'\b\d+\b', text_content)]
        total_products = numbers[1]
        print(f'Total Products: {total_products}')
    except Exception as e:
        print(f"Error fetching total products: {e}")
        total_products = 0

    grap_product = 0
    #total_products = 60
    while total_products > 0:
        try:
            button = WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.XPATH, '//button[text()="Visa fler produkter"]')))
            button.click()
            total_products -= 30
            grap_product += 30
            print(f'{grap_product} Product Links have been successfully grabbed. Please wait.')
            time.sleep(2)
        except StaleElementReferenceException:
            pass
        except TimeoutException:
            print("Button not clickable. Exiting the loop.")
            break

    # Extract product links
    try:
        # Extract product links
        products_list = []
        page_source = driver.page_source
        soup = BeautifulSoup(page_source, 'html.parser')
        products_div = soup.find_all('a', class_='sc-kDvujY iilEvk h-full')

        for product_link in products_div:
            product_href = product_link.get('href')
            product_url = BaseURL + product_href
            products_list.append(product_url)
    except Exception as e:
        print(f"Error extracting product URLs: {e}")
        # Handle the error or exit the program if necessary

    # Write product URLs to CSV file
    with open(product_cards_filename, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        # Write each URL as a separate row
        for product_url in products_list:
            writer.writerow([product_url])

    print(f"Product cards saved to {product_cards_filename}")

    if not products_list:
        print("No product URLs found. Exiting the program.")
        driver.quit()
        sys.exit()

    print('Please wait. Data is being prepared for database insertion and Product Details')
    time.sleep(3)

# Read existing product_links from product_cards.csv
with open(product_cards_filename, 'r', newline='', encoding='utf-8') as csvfile:
    reader = csv.reader(csvfile)
    next(reader)  # Skip the header row
    products_list = [row[0] for row in reader if row]  # Skip empty rows

# now product detail is fetching
for product_url in products_list:
    # now product detail is fetching
    productName = ""
    productsubtitle = ""
    productprice = ""
    ProductBrand = ""
    product_description = ""
    product_instructions = ""
    category_name_list = []
    image_list = []
    productEAN = ''
    Size = ''
    rating = ''
    sites_id = get_sites_id(product_url)
    link= product_url

    driver.get(product_url)
    time.sleep(2)

    # Check if the cookie popup exists and click it if present
    try:
        cookie_button = driver.find_element(By.XPATH, 'your_cookie_popup_xpath')
        cookie_button.click()
        print("Clicked on the cookie popup.")
    except NoSuchElementException:
        print("Cookie popup not found. Continuing without clicking.")

    # Check if the button is clickable within the timeout
    button = None
    try:
        button = WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.CSS_SELECTOR, '.sc-eDvSVe.kogbNh')))
    except TimeoutException:
        print("Button not clickable within the timeout. Continuing without clicking.")

    # If the button is found and clickable, proceed to click it
    if button:
        try:
            button.click()
            total_products -= 30
            grap_product += 30
            print(f'{grap_product} Product Links have been successfully grabbed. Please wait.')
            time.sleep(3)
        except StaleElementReferenceException:
            pass

    page_source = driver.page_source
    soup = BeautifulSoup(page_source, 'html.parser')
    Main_product_div = soup.find_all('div',class_='content-container')
    Main_product_div = Main_product_div[3]

    productName = Main_product_div.find('h1').text
    productsubtitle = Main_product_div.find('h2').text
    image_div =  Main_product_div.find_all('img')


    productprice_main_div = Main_product_div.find('div',class_='sc-m22epw-0')
    productprice_sapn = productprice_main_div.find_all('span')
    productprice = productprice_sapn[1].text

    product_review = Main_product_div.find('div', class_='testfreaks-badge')

    # Check if product_review is not None before trying to find 'tf-rating'
    if product_review:
        rating_element = product_review.find('div', class_='tf-rating')

        # Check if rating_element is not None before trying to access 'text'
        if rating_element:
            rating = rating_element.text
        else:
            # If tf-rating is not directly under testfreaks-badge, traverse further
            tf_row = product_review.find('div', class_='tf-row')
            if tf_row:
                rating_element = tf_row.find('div', class_='tf-rating')
                rating = rating_element.text if rating_element else 'N/A'
            else:
                rating = 'N/A'
    else:
        rating = 'N/A'  # Set a default value if 'testfreaks-badge' element is not found


    left_side_of_product = Main_product_div.find('div',class_='flex flex-col min-w-0')

    ProductBrand = Main_product_div.find('div',class_='sc-1isczkx-0 cEiCa').find('a').text.replace('Fler produkter från','')
    # Remove leading and trailing spaces
    ProductBrand = ProductBrand.strip()

    left_side_of_product_level = left_side_of_product.find_all('div',class_='isolate mb-3 flex flex-col rounded-xl outline outline-1 outline-gray-100')

    left_side_of_product_level_first = left_side_of_product_level[0]
    left_side_of_product_level_last = left_side_of_product_level[len(left_side_of_product_level) - 1]

    all_p_tag_of_left_side = left_side_of_product_level_first.find_all('p')
    
    #category
    all_a_tag_of_left_side = left_side_of_product_level_first.find_all('a')

    total_num = len(all_p_tag_of_left_side)
    p_tag_productEAN = all_p_tag_of_left_side[total_num - 2].text
    productEAN = ''.join(filter(str.isdigit, p_tag_productEAN))
    if len(productEAN) >= 12 and productEAN[0] == '0':
        productEAN = productEAN[1:]  # Remove the leading '0'
        print("EAN Number:", productEAN)

    else:
        print("Original EAN Number:", productEAN)
    
    '''# Check if EAN has more than 13 digits
    if len(productEAN) > 13:
        print("EAN has more than 13 digits. Adjusting...")

        # Assuming you want to keep only the first 13 digits
        productEAN = productEAN[:13]
        print("Adjusted EAN Number:", productEAN)

    # Check if EAN has exactly 13 digits and starts with '0'
    elif len(productEAN) == 13 and productEAN[0] == '0':
        productEAN = productEAN[1:]  # Remove the leading '0'
        print("Adjusted EAN Number:", productEAN)'''

    product_description = all_p_tag_of_left_side[0].text

    # Load the category assignment CSV file
    category_assignment_df = pd.read_csv('category_assignments.csv')

    # Initialize lists for all categories and parent categories
    all_categories = []
    parent_categories_set = set()

    # Assuming all_a_tag_of_left_side is a list of elements containing category names
    for cat in all_a_tag_of_left_side:
        category = cat.text.strip()
        all_categories.append(category)
        
        # Check if the category name exists in the CSV file
        if category in category_assignment_df['CategoryName'].values:
            # Get the parent category value for the matched category name
            parent_category = category_assignment_df.loc[
                category_assignment_df['CategoryName'] == category, 'ParentCategory'].iloc[0]
            # Assign the parent category value to the scraped category
            parent_categories_set.add(parent_category)

    # Convert the set to a list for the database
    parent_categories = list(parent_categories_set)

    # Print the lists for demonstration
    print("All Categories:", all_categories)
    print("Parent Categories:", parent_categories)


    image_list = [img['src'] for img in image_div if not img.get('src').startswith('data:image/svg+xml')]

    product_instructions = left_side_of_product_level_last.text


    # print(f'productEAN\n {productEAN}')
    # print(f'productName\n {productName}')
    # print(f'productsubtitle\n {productsubtitle}')
    # print(f'productprice\n {productprice}')
    # print(f'ProductBrand\n {ProductBrand}')
    # print(f'product_description\n {product_description}')
    # print(f'product_instructions\n {product_instructions}')
    # print(f'category_name_list\n {category_name_list}')
    # print(f'image_list\n {image_list}')
    # print(f'Size\n {Size}')
    # print(f'rating\n {rating}')
    # print(f'sites_id\n {sites_id}')

    DatabaseObj = DatabaseFunction()
    DatabaseObj.insertion(productName, productsubtitle, productprice, ProductBrand, product_description, product_instructions, parent_categories, image_list, productEAN, Size, rating,sites_id, formatted_datetime, link)
    time.sleep(2)
driver.quit()