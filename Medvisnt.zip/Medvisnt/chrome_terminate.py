#Track the PIDs: When you create a new WebDriver instance, capture its PID.
#Close Specific Instances: When you want to close the Selenium-initiated Chrome instances, use the stored PIDs to close them selectively.

import os
import time
from selenium import webdriver

# Dictionary to store WebDriver instances and their PIDs
driver_processes = {}

def initialize_driver():
    chrome_options = webdriver.ChromeOptions()
    # Add options as needed
    driver = webdriver.Chrome(options=chrome_options)
    # Store the process ID (PID) of the driver instance
    driver_processes[driver] = driver.service.process.pid
    return driver

def close_driver(driver):
    # Retrieve the PID from the dictionary
    pid = driver_processes.get(driver)
    if pid:
        # Use the PID to kill the process
        os.system(f"taskkill /f /pid {pid}")
        # Remove the entry from the dictionary
        del driver_processes[driver]
    else:
        print("Driver PID not found.")

# Example usage
driver1 = initialize_driver()
# Do something with driver1
time.sleep(5)  # Simulate some activity
close_driver(driver1)

# You can use the same approach for multiple WebDriver instances
# driver2 = initialize_driver()
# time.sleep(5)
# close_driver(driver2)
