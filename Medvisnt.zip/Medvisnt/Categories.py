import csv
from fuzzywuzzy import fuzz

# Function to find best match for each category
def find_best_match(category, main_categories):
    # Initialize variables for best match and score
    best_match = None
    highest_score = -1
    
    # Iterate through all main categories
    for main_category in main_categories:
        # Calculate fuzzy match score
        score = fuzz.partial_ratio(category.lower(), main_category.lower())
        
        # Update best match if score is higher
        if score > highest_score:
            highest_score = score
            best_match = main_category
    
    return best_match, highest_score

# Main categories to match against
matching_categories = [
    "Allergimedicin",
    "Ansikte",
    "Barn & Förälder",
    "Dermatologisk Hudvård",
    "Djur",
    "Elektronik",
    "Feber & Värk",
    "Hem & Städprodukter",
    "Hjälpmedel & Tillbehör",
    "Förkylning",
    "Hud",
    "Hår",
    "Händer & Fötter",
    "Intimvård",
    "Mage & Tarm",
    "Mat & Dryck",
    "Mun & Tänder",
    "Professionell Skönhet",
    "Sår, bett och stick",
    "Sex & Lust",
    "Sluta röka",
    "Smink & Makeup",
    "Solskydd",
    "Vitaminer & Kosttillskott",
    "Träning & Vikt",
    "Ögon & Öron"
]

# Load categories from CSV
csv_categories = []
with open('category.csv', newline='', encoding='utf-8') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        csv_categories.append(row['CategoryName'])

# Dictionary to store matched categories
matched_categories = {}

# Set the threshold for considering a match
threshold = 75  

# Match each category
for category in csv_categories:
    matched_category, score = find_best_match(category, matching_categories)
    
    # Check if the score meets the threshold
    if score >= threshold:
        matched_categories[category] = {'Matched Category': matched_category, 'Score': score}
    #else:
        #matched_categories[category] = {'Matched Category': None, 'Score': score}

# Print the matched categories
for category, match_info in matched_categories.items():
    print(f"{category} -> {match_info['Matched Category']} (Score: {match_info['Score']})")
