import requests
from bs4 import BeautifulSoup
import csv
from urllib.parse import urlparse
import os
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import re
from DatabaseFunction import DatabaseFunction, get_sites_id
from datetime import datetime

# Get the current date and time
current_datetime = datetime.now()
f_datetime = current_datetime.strftime("%Y-%m-%d %H:%M:%S")
print("Scraping Started at :",f_datetime)


# Function to get hrefs from a given URL
def get_hrefs(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Find the div with class "filter-options-content"
    filter_div = soup.find('div', class_='filter-options-content')

    # Find all anchor tags within the div
    anchor_tags = filter_div.find_all('a', href=True)

    # Extract and return hrefs
    return [tag['href'] for tag in anchor_tags]

# Function to get product hrefs from a given URL
def get_product_hrefs(url):
    product_hrefs = []
    while url:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Find all anchor tags with class "product-item-link"
        product_anchor_tags = soup.find_all('a', class_='product-item-link', href=True)

        # Extract and add product hrefs
        product_hrefs.extend([tag['href'] for tag in product_anchor_tags])

        # Find the next page link
        next_page_link = soup.find('a', class_='next', href=True)
        url = next_page_link['href'] if next_page_link else None

    return product_hrefs

# Function to extract price using Selenium
def get_price_with_selenium(product_url):
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Run Chrome in headless mode (no GUI)

    with webdriver.Chrome(options=chrome_options) as driver:
        driver.get(product_url)

        # Execute JavaScript code in the browser to extract the price
        price = driver.execute_script("""
            const priceElement = document.querySelector('.text-lg.md:text-3xl.font-bold.block.text-promotion') ||
                                document.querySelector('.text-promotion');
            return priceElement ? priceElement.textContent.trim() : null;
        """)

        return float(price) if price else None

# Function to get image URLs from a given HTML content
def get_image_urls(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')

    # Find the main div with class "product-main-full-width"
    main_div = soup.find('main', class_='product-main-full-width')

    # Find all image tags within the main div
    image_tags = main_div.find_all('img', src=True)

    # Extract and return image URLs
    return [tag['src'] for tag in image_tags]

# Write data to CSV file
csv_filename = 'dozapotek.csv'

# Check if the CSV file exists
if os.path.exists(csv_filename):
    print(f"{csv_filename} already exists. Using existing product_links.")

else:
    # CSV file does not exist, continue with collection
    print(f"{csv_filename} does not exist. Starting collection.")

    with open(csv_filename, 'w', newline='', encoding='utf-8') as csvfile:
        csv_writer = csv.writer(csvfile)
        # Write header row
        csv_writer.writerow(['Category', 'HREF'])
        
        # URLs to scrape
        category_urls = [
            "https://dozapotek.se/egenvard.html",
            "https://dozapotek.se/skonhet-kroppsvard.html",
            "https://dozapotek.se/kost-halsa.html",
            "https://dozapotek.se/mun-och-tander.html",
            "https://dozapotek.se/barn-och-foralder.html",
            "https://dozapotek.se/djurvard.html",
            "https://dozapotek.se/fler-kategorier.html"
        ]

        # Loop through each category URL
        for category_url in category_urls:
            print(f"\nProcessing Category URL: {category_url}")
            
            # Get parent category from the URL without the ".html" extension
            parent_category = urlparse(category_url).path.strip('/').replace('.html', '')
            print(f"Parent Category: {parent_category}")

            # Get all hrefs from the category page
            hrefs = get_hrefs(category_url)
            
            # Loop through each href and get product hrefs
            for href in hrefs:
                # Get secondary category from the href
                secondary_category = href.split('/')[-1].split('.')[0]
                print(f"\nProcessing Secondary Category: {secondary_category}")
                
                # Get product hrefs from multiple pages
                product_hrefs = get_product_hrefs(href)
                
                # Write data to CSV
                for product_href in product_hrefs:
                    print(f"Saving: {parent_category}/{secondary_category}, {product_href}")
                    csv_writer.writerow([f"{parent_category}/{secondary_category}", product_href])

    print(f"\nCSV file '{csv_filename}' created successfully.")

# Read URLs from the existing CSV file
with open(csv_filename, 'r', newline='', encoding='utf-8') as csvfile:
    csv_reader = csv.reader(csvfile)
    next(csv_reader)  # Skip header row

    item_id_counter=1

    # Loop through each row and scrape data for each URL
    for row in csv_reader:
        category_and_url = row[0]
        product_url = row[1]  # Assuming the URL is in the second column
        print(f"\nProcessing product URL: {product_url}")

        # Item ID
        print(f"Item ID: {item_id_counter}")
        item_id_counter += 1  # Increment the counter for the next item

        link = product_url
        print(link)
        
        # Split category_and_url into category and secondary_category
        category, secondary_category = category_and_url.split('/')

        # Initialize an empty list to store categories
        category_list = []

        # Append categories to the list
        category_list.append(category)
        category_list.append(secondary_category)
        print(category_list)
        
        # Define a user agent
        user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"

        # Make a GET request with the specified user agent
        response = requests.get(product_url, headers={"User-Agent": user_agent})
        # Make a request to the URL and get the HTML content
        html_content = response.text

        # Get image URLs from the HTML content
        image_urls = get_image_urls(html_content)

        # Parse the HTML content
        soup = BeautifulSoup(html_content, 'html.parser')

        # Find the div containing "Lägsta pris de senaste 30 dagarna"
        price_div = soup.find('th', string='Lägsta pris de senaste 30 dagarna')

        if price_div:
            # Find the parent row
            price_row = price_div.find_parent('tr')

            if price_row:
                # Find the data cell containing the price
                price_cell = price_row.find('td', class_='col data w-full py-2 pl-2 text-left text-gray-900')

                if price_cell:
                    # Find the span element containing the price
                    price_span = price_cell.find('span', class_='price')

                    if price_span:
                        # Extract and replace commas with periods in the price
                        price = price_span.get_text(strip=True).replace(',', '.')
                        print(f"The price is: {price}")
                    else:
                        print("Price span not found.")
                else:
                    print("Price data cell not found.")
            else:
                print("Price row not found.")
        else:
            print("Lägsta pris de senaste 30 dagarna not found.")
        

        # instructions
        instructions_div = soup.find('th', string='Mer information')

        if instructions_div:
            # Find the parent row
            instructions_row = instructions_div.find_parent('tr')

            if instructions_row:
                # Find the data cell containing the instructions
                instructions_cell = instructions_row.find('td', class_='col data w-full py-2 pl-2 text-left text-gray-900')

                if instructions_cell:
                    # Extract and print the instructions
                    instructions = instructions_cell.get_text(strip=True)
                    print(f"Product Instructions: {instructions}")
                else:
                    print("Instructions data cell not found.")
            else:
                print("Instructions row not found.")
        else:
            print("Instructions not found.")
            
            
        #size
        size_div = soup.find('th', string='Förpackningstyp')

        if size_div:
            # Find the parent row
            size_row = size_div.find_parent('tr')

            if size_row:
                # Find the data cell containing the size information
                size_cell = size_row.find('td', class_='col data w-full py-2 pl-2 text-left text-gray-900')

                if size_cell:
                    # Extract and print the size information
                    size_info = size_cell.get_text(strip=True)
                    print(f"Size Information: {size_info}")
                else:
                    print("Size information data cell not found.")
            else:
                print("Size information row not found.")
        else:
            print("Size not found.")

        # If size_info is not found, set it to the default value "N/A"
        size_info = size_info if 'size_info' in locals() else 'N/A'

        
        ean_div = soup.find('th', string='Varunummer')

        if ean_div:
            # Find the parent row
            ean_row = ean_div.find_parent('tr')

            if ean_row:
                # Find the data cell containing the EAN
                ean_cell = ean_row.find('td', class_='col data w-full py-2 pl-2 text-left text-gray-900')

                if ean_cell:
                    # Extract and print the EAN
                    ean = ean_cell.get_text(strip=True)
                    print(f"EAN: {ean}")
                else:
                    print("EAN data cell not found.")
            else:
                print("EAN row not found.")
        else:
            print("EAN not found.")

        #Brand
        # Find the div containing "Varumärke"
        brand_div = soup.find('th', string='Varumärke')

        if brand_div:
            # Find the parent row
            brand_row = brand_div.find_parent('tr')

            if brand_row:
                # Find the data cell containing the brand
                brand_cell = brand_row.find('td', class_='col data w-full py-2 pl-2 text-left text-gray-900')

                if brand_cell:
                    # Extract and print the brand
                    brand = brand_cell.get_text(strip=True)
                    print(f"Brand: {brand}")
                else:
                    print("Brand data cell not found.")
            else:
                print("Brand row not found.")
        else:
            print("Varumärke not found.")    
        brand= brand.strip()
        
        # Get product name
        name_h1 = soup.find('h1', class_='text-base')
        product_name = name_h1.text.strip() if name_h1 else 'N/A'
        print(f"Product Name: {product_name}")

        # Get product description
        description_div = soup.find('div', class_='bg-white flex flex-row items-center')
        if description_div:
            description_span = description_div.find('span', class_='block')
            if description_span:
                product_description = description_span.text.strip()
                print(f"Product Description: {product_description}")
            else:
                print("Product Description not found within the span element.")
        else:
            print("Product Description not found within the div element.")
            
        productName = product_name
        productsubtitle = ''
        productprice = price
        ProductBrand = brand
        product_description = product_description
        product_instructions = instructions
        category_name_list = category_list
        image_list = image_urls
        productEAN = ean
        Size = size_info
        rating = 'N/A'
        sites_id = get_sites_id(link)
        link = link
        formatted_datetime = f_datetime

        print("------------")  # Separator between products
        # Insert or update information into the MySQL database using DatabaseFunction
        DDB = DatabaseFunction()
        DDB.insertion(
        productName, productsubtitle, productprice, ProductBrand,
        product_description, product_instructions, category_name_list,
        image_list, productEAN, Size, rating, sites_id,
        formatted_datetime, link)
        print(f"This product is Added/Updated Successfully: {product_name}")