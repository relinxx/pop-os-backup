import requests
from bs4 import BeautifulSoup
import time
import re
from urllib.parse import urljoin, urlparse
import csv
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException, StaleElementReferenceException
from datetime import datetime
from DatabaseFunction import DatabaseFunction
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains

# Get the current date and time
current_datetime = datetime.now()
f_datetime = current_datetime.strftime("%Y-%m-%d %H:%M:%S")
print("Scraping Started at :",f_datetime)


def load_more():
    try:
        while True:
            load_more_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, '//div[@class="row loadMore text-center"]/div/a[contains(text(), "+ Visa fler")]'))
            )
            load_more_button.click()
            time.sleep(5)
    except StaleElementReferenceException:
        print("Button is no longer clickable. Stopping.")
    except Exception as e:
        print(f"Error: {e}")
        
        
# Function to check if the page is invalid based on the presence of certain elements/classes
def is_invalid_page(driver):
    try:
        # Check for breadcrumb indicating "Ogiltig adress"
        breadcrumb = driver.find_element(By.XPATH, '//ul[@class="breadcrumb"]/li/span[contains(@class, "current") and text()="Ogiltig adress"]')
        return True

    except NoSuchElementException:
        pass

    try:
        # Check for the mainContent div containing a specific image
        main_content_div = driver.find_element(By.XPATH, '//div[@class="col-md-12 mainContent"]/p/a/img[contains(@src, "/globalassets/404-banner/404_sidan_siten_1280x350px.jpg")]')
        return True

    except NoSuchElementException:
        pass

    return False


def cookie_button():
    try:
        wait = WebDriverWait(driver, 2)
        button_xpath = '//*[@id="onetrust-accept-btn-handler"]'
        popup_button = wait.until(EC.element_to_be_clickable((By.XPATH, button_xpath)))
        if popup_button:
            popup_button.click()
    except TimeoutException:
        print("Popup did not appear within the specified timeout.")
    except Exception as e:
        print(f"Error handling modal: {e}")

def scroll_down(driver, pixels=100):
    script = f"window.scrollBy(0, {pixels});"
    driver.execute_script(script)

def extract_size(product_name):
    # Define regular expressions for different size patterns
    size_patterns = [
        r'(?i)\b(?:Vit|Grå|Black|White)\b\s*(\d+\s*[a-zA-Z]+[-\s]*[a-zA-Z]*)$',  
        r'(\d+\s*[a-zA-Z]+[-\s]*[a-zA-Z]*)$',  
        r'([a-zA-Z]+[-\s]*\d+[-\s]*[a-zA-Z]*)$',  
    ]

    # Try to find a matching size pattern in the product name
    for pattern in size_patterns:
        match = re.search(pattern, product_name)
        if match:
            return match.group(1).strip()

    # Return None if no size pattern is found
    return None

def scrape_price(url):
    # Make a request to the URL
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')

    # Check for Kampanjpris
    kampanjpris_price = get_price_for_label(soup, 'Kampanjpris')
    if kampanjpris_price:
        return kampanjpris_price

    # Check for Klubbpris
    klubpris_price = get_price_for_label(soup, 'Klubbpris')
    if klubpris_price:
        return klubpris_price

    # If not Kampanjpris or Klubbpris, check for Webbpris
    webbpris_price = get_price_for_label(soup, 'Webbpris')
    return webbpris_price

def get_price_for_label(soup, label):
    # Find the element with the specified label
    label_element = soup.find('p', string=label)

    if label_element:
        # Get the sibling span containing the price
        price_element = label_element.find_next('span', class_='MuiTypography-root')
        if price_element:
            return price_element.string.strip()

    return None

# Set up Selenium webdriver with headless mode and a custom user agent
options = webdriver.ChromeOptions()
# options.add_argument("--headless")  # Add headless mode
user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
options.add_argument(f"user-agent={user_agent}")
print("Driver initialized successfully")

#adding driver logs 'chrome.log'
service_args = ["--verbose", "--log-path=chrome.log"]
#driver = webdriver.Chrome(options=options, service_args=service_args)

# Create Chrome webdriver instance with the specified options
driver = webdriver.Chrome(options=options)

product_cards_data = []
Brand_Links = []
product_cards_filename='apotekhjartat.csv'

# Check if the product_cards.csv file exists
if os.path.exists(product_cards_filename):
    print(f"{product_cards_filename} already exists. Using existing product_links.")
    
    # Read existing product_links from product_cards.csv
    with open(product_cards_filename, 'r', newline='', encoding='utf-8') as csvfile:
        reader = csv.reader(csvfile)
        next(reader)  # Skip the header row
        #product_links = [row[0] for row in reader if row]  # Skip empty rows
        product_links = list(set(row[0] for row in reader if row))
        

else:
    # product_cards.csv file does not exist, continue with brand_card and product_card collection
    print(f"{product_cards_filename} does not exist. Starting brand_card and product_card collection.")

    Base_URL = "https://www.apotekhjartat.se/"
    brand_cards = "https://www.apotekhjartat.se/varumarken/"
    response = requests.get(brand_cards)
    soup = BeautifulSoup(response.content, 'html.parser')
    #//*[@id="CybotCookiebotDialogBodyButtonDecline"]

    #Brand_element = soup.select('#mainContentHolder > div:nth-child(3) > div:nth-child(3) > div:nth-child(2)')
    #Brand_element = soup.find('div', id='clubLoginModal')

    brand_elements = soup.select('.brandpage--list__item li a')
    #print(brand_elements)
    if brand_elements:
    # Extract and print the href attribute of each link
        for brand_element in brand_elements:
            
            link = brand_element.get('href')
            #print(link)
            if link is not None:
                full_link = urljoin(Base_URL, link)
                Brand_Links.append(full_link)
                #print(full_link)
    else:
        print("no links")
    print(len(brand_elements))
    print(len(Brand_Links))
    # Print the type of the variable
    print(type(driver))

    for brand in Brand_Links:
        driver.get(brand)
        cookie_button()
        load_more()
        page_source = driver.page_source

        # Use BeautifulSoup to parse the HTML
        soup = BeautifulSoup(page_source, 'html.parser')

        # Find all <a> tags with class "gmt-click"
        a_tags = soup.find_all('a', class_='gmt-click')

        # Extract and print href attributes
        for a_tag in a_tags:
            href = a_tag['href']
            product_cards_data.append([href])
            print(href)
            # Save product cards to a CSV file
    # Save product cards to a CSV file
    if not os.path.exists(product_cards_filename):
        with open(product_cards_filename, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerows(product_cards_data)
        print(f"Product cards saved to {product_cards_filename}")
#link_element = driver.find_element_by_xpath('//*[@id="advice-slider"]/div/ul/li[1]/div/div[2]/h6/a')

item_id_counter=1
start_index = product_links.index('https://www.apotekhjartat.se/produkt/max-factor-masterpiece-liquid-eyeliner-espresso/') +1
for product_link in product_links[start_index:]:
    try:
        rating_text='N/A' # Reset rating_text for each new product
        driver.get(product_link)
        cookie_button()
        
        # Check if the page is invalid
        if is_invalid_page(driver):
            print(f"Skipping invalid page: {product_link}")
            continue
        
        link=product_link
        # (1) Item ID
        print(f"(1) Item ID: {item_id_counter}")
        item_id_counter += 1  # Increment the counter for the next item

        main_div = driver.find_element(By.CLASS_NAME, 'MuiPaper-root')

        # (2) product name
        product_name_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, '//*[@id="__next"]/div[4]/div/div/div/div[2]/div/div[1]/div/div[1]/div[2]/div[1]/h1'))
        )

        if product_name_element:
            product_name = product_name_element.text.strip()
            print("(2) Product Name:", product_name)
        else:
            print("(2) Product name not found.")

        #(11) Description
        try:
            # Wait for the presence of the element with the heading
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "//h3[contains(text(), 'Detaljerad produktbeskrivning')]"))
            )

            # Extract the product description using BeautifulSoup
            soup = BeautifulSoup(driver.page_source, 'html.parser')
            product_description_element = soup.find('h3', string='Detaljerad produktbeskrivning')
            
            if product_description_element:
                product_description = product_description_element.find_next('span').get_text(strip=True)
                print('(11) Description:', product_description)
            else:
                print("Product description not found on this page.")
                product_description='N/A'

        except Exception as e:
            print(f"Error scraping product description: {e}")
    
        #(3)Price
        price_element= scrape_price(product_link)

        # Extract and print the formatted price
        if price_element:
            price = price_element.replace(":-", "").replace(":", ".").strip() + " Kr"
            print("(3) Price:", price)
        else:
            print("(3) Price not found.")
            
        #(9) Image Links
        #url = 'https://www.apotekhjartat.se/produkt/ellwo-moisturizing-shampoo-100-ml/'
        response = requests.get(product_link)
        soup = BeautifulSoup(response.text, 'html.parser')
        image_elements = soup.find_all('img')
        image_urls = [img['src'] for img in image_elements if 'www.w3.org' not in img['src']]

        # Create a list of valid external image URLs
        valid_image_urls = []
        for url in image_urls:
            parsed_url = urlparse(url)
            if parsed_url.netloc:  # Check if it's an absolute URL
                valid_image_urls.append(url)

        # Print or use the list of valid image URLs
        for i, url in enumerate(valid_image_urls, 1):
            print(f"(9) Image URL {i}: {url}")
            
        '''# (9) Image link
        try:
            # Find the image element
            image_element1 = driver.find_element(By.XPATH, f"//img[@alt='{product_name}']")

            # Get the src attribute containing the image URL
            image_url1 = image_element1.get_attribute('src')
            print('(9) Image link:', image_url1)

        except Exception as e:
            print(f"Error: {e}")'''


        #(4)link
        link=product_link
        print("(4) link :",link)
        
        # Get the product name
        product_name = driver.find_element(By.XPATH, '//*[@id="__next"]/div[4]/div/div/div/div[2]/div/div[1]/div/div[1]/div[2]/div[1]/h1').text.strip()
            
        '''
        #(9)Images
        response = requests.get(product_link)
        soup = BeautifulSoup(response.text, 'html.parser')

        # Find the image element
        image_element = soup.find('img', alt='Löwengrip Level Up Volumizing Hair Mask 200 ml')

        if image_element:
            # Get the src attribute containing the image URL
            image_url = image_element['src']
            print(f"The image URL is: {image_url}")
        else:
            print("Image URL not found.")
            
        # (3) price
        # Define the keywords associated with different prices
        price_keywords = ["Klubbpris", "Kampanjpris", "Webbpris"]

        # Initialize the price_text variable outside the loop
        price_text = None

        # Iterate through each keyword to find the corresponding price
        for keyword in price_keywords:
            price_xpath = f'//*[contains(p, "{keyword}")]/following-sibling::span[contains(@class, "MuiTypography-body1")]'

            try:
                price_element = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.XPATH, price_xpath))
                )

                if price_element:
                    price_text = price_element.text.strip()
                    print(f"(3) {keyword} Price:", price_text)
                    if keyword in ["Klubbpris", "Kampanjpris"]:
                        # If it's Klubbpris or Kampanjpris, break the loop and prioritize it
                        break

            except NoSuchElementException:
                print(f"{keyword} Price element not found.")

        # Check if a price is found and format it
        if price_text:
            price_text = extract_size(price_text)
            print(f'Formatted price: {price_text}')
        else:
            print("Price not found.")
            
        '''

        # Scroll down using JavaScript
        for i in range(1):  # Scroll 3 times, you can adjust the number as needed
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(1)  # Add a delay to allow the content to load

        # Click the button to expand the accordion
        try:
            # Wait for the presence of the button based on the text "Produktfakta"
            button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, '//h2[text()="Produktfakta"]/ancestor::div[@role="button"]'))
            )

            # Scroll into view
            actions = ActionChains(driver)
            actions.move_to_element(button).perform()

            # Click the button
            button.click()
            print("Button clicked successfully.")

        except Exception as e:
            print(f"Error clicking the button: {e}")

        # (5) Apotekets varuid
        apotekets_varuid_xpath = '//*[contains(h3, "Apotekets varuid")]/following-sibling::div/span[contains(@class, "MuiListItemText-primary")]'

        try:
            # Find the element next to "Apotekets varuid"
            apotekets_varuid_element = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, apotekets_varuid_xpath))
            )

            if apotekets_varuid_element:
                apotekets_varuid_number = apotekets_varuid_element.text.strip()
                print("(5) Apotekets varuid Number:", apotekets_varuid_number)

            else:
                raise NoSuchElementException

        except NoSuchElementException:
            print("Apotekets varuid element not found.")
            
        # (6) EAN
        ean_xpath = '//*[contains(h3, "EAN")]/following-sibling::div/span[contains(@class, "MuiListItemText-primary")]'

        try:
            # Find the element next to "EAN"
            ean_element = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, ean_xpath))
            )

            if ean_element:
                ean_number = ean_element.text.strip()
                print("(6) EAN Number:", ean_number)

                # Check if it's a 13-digit number and starts with '0'
                if len(ean_number) == 13 and ean_number[0] == '0':
                    ean_number = ean_number[1:]  # Remove the leading '0'
                    print("Adjusted EAN Number:", ean_number)

            else:
                raise NoSuchElementException

        except NoSuchElementException:
            print("EAN element not found.")

        # Initialize an empty list to store categories
        categories_list = []
        
        # (7) Categories
        kategori_xpath = '//*[contains(h3, "Kategori")]/following-sibling::div/span/a[contains(@class, "MuiTypography-inherit")]'

        try:
            # Find the elements next to "Kategori"
            kategori_elements = WebDriverWait(driver, 10).until(
                EC.presence_of_all_elements_located((By.XPATH, kategori_xpath))
            )

            if kategori_elements:
                # Extract and print the categories
                categories_list = [element.text.strip() for element in kategori_elements]
                print("(7) Categories:", categories_list)
                categories_string = ', '.join(categories_list)

            else:
                raise NoSuchElementException

        except NoSuchElementException:
            print("Categories element not found.")
            categories_list = []

        # (8) brand
        brand_xpath = '//*[contains(h3, "Varumärken")]/following-sibling::div/span/a[contains(@class, "MuiTypography-inherit")]'

        try:
            # Find the brand element next to "Varumärken"
            brand_element = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, brand_xpath))
            )

            if brand_element:
                # Extract and print the brand
                brand = brand_element.text.strip()
                print("(8) Brand:", brand)

            else:
                raise NoSuchElementException

        except NoSuchElementException:
            print("Brand element not found.")
            brand = "N/A"

        '''# (9) Images
        try:
            # Find the image element
            image_element = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, f'//span[contains(@style, "max-width:100%")]/img[@alt="{product_name}"]'))
            )

            if image_element:
                # Extract the image source URL
                image_src = image_element.get_attribute("src")
                print("(9) Image Source:", image_src)

            else:
                raise NoSuchElementException

        except NoSuchElementException:
            print("Image element not found.")
            image_src = "N/A" '''

        productName = product_name
        productsubtitle = apotekets_varuid_number
        productprice = price
        ProductBrand = brand
        product_description = product_description
        product_instructions = ''
        category_name_list = categories_string
        image_list = [valid_image_urls]
        productEAN = ean_number
        Size = ''
        rating = ''
        sites_id = 5
        link= link
        formatted_datetime = f_datetime

        print("-------------------")  # Separator between products
        # Insert or update information into the MySQL database using DatabaseFunction
        DDB = DatabaseFunction()
        DDB.insertion(
        productName, productsubtitle, productprice, ProductBrand,
        product_description, product_instructions, category_name_list,
        image_list, productEAN, Size, rating, sites_id,
        formatted_datetime, link)
        print(f"This product is Added/Updated Successfully: {product_name}")
    except Exception as e:
        print(f"Error processing product link {product_link}: {e}")
        continue  # Continue to the next iteration of the loop

    except Exception as e:
            print(f"Error processing product link {product_link}: {e}")
            continue  # Continue to the next iteration of the loop
    
driver.quit()

