import requests
from bs4 import BeautifulSoup
from tqdm import tqdm
import time
import re
from DatabaseFunction import DatabaseFunction, get_sites_id
import os
import csv
import pandas as pd

from datetime import datetime
current_datetime = datetime.now()
formatted_datetime = current_datetime.strftime("%Y-%m-%d %H:%M:%S")

Product_Links = []
Brand_Links = []
product_cards_filename='apohem.csv'

print('Calculate the total number of Brand.')
Base_URL = "https://www.apohem.se"
All_brand_lilst = "https://www.apohem.se/varumarken"


# Check if the product_cards.csv file exists
if os.path.exists(product_cards_filename):
    print(f"{product_cards_filename} already exists. Using existing product_links.")
    
else:
    response = requests.get(All_brand_lilst)
    soup = BeautifulSoup(response.content, 'html.parser')

    Brand_link_div = soup.find('div', id='content-container')
    All_ul_tag = Brand_link_div.find_all('ul')



    for li_div in All_ul_tag:
        all_li = li_div.find_all('li')
        for a_tag in all_li:
            href = a_tag.find('a')['href']
            Brand_Links.append(Base_URL+href)


    print(f'Total Brand. {len(Brand_Links)}')

    with tqdm(total=len(Brand_Links), desc="Scraping Product Links through brand ") as pbar:
        for Brand_link in Brand_Links:
            response = requests.get(Brand_link)
            if response.status_code == 200:
                soup = BeautifulSoup(response.content, 'html.parser')
                text_content = soup.find('div', string=re.compile(r'Du har tittat')).text
                numbers = [int(num) for num in text_content.split() if num.isdigit()]
                if numbers[0] == numbers[1]:
                    product_list_div = soup.find('div', id='product-list')
                    if product_list_div:
                        try:
                            All_product_a = product_list_div.find_all('a')
                            if All_product_a:
                                for href_link in All_product_a:
                                    try:
                                        href = href_link['href']
                                        Product_Links.append(Base_URL + href)
                                    except:
                                        pass
                        except:
                            pass  
                else:
                    start = 25
                    skip = 0
                    previous_start = 0
                    while numbers[1] > start:
                        print(f'Scraping More Link from this uri {Brand_link}')
                        # print(f"{Brand_link}?count={start}&skip={skip}")
                        url = f"{Brand_link}?count={start}&skip={skip}"
                        response = requests.get(url)
                        soup = BeautifulSoup(response.content, 'html.parser')
                        product_list_div = soup.find('div', id='product-list')
                        if product_list_div:
                            try:
                                All_product_a = product_list_div.find_all('a')
                                if All_product_a:
                                    for href_link in All_product_a:
                                        try:
                                            href = href_link['href']
                                            Product_Links.append(Base_URL + href)
                                        except:
                                            pass
                            except:
                                pass
                        previous_start = start
                        start += 25
                        skip += 25
                        if int(start) > int(numbers[1]):
                            extra = int(start) - int(numbers[1])
                            start = int(start) - int(extra)
            else:
                print('Maximum requests are being sent. Please wait.')
            pbar.update(1)
            time.sleep(1)
    print('Please wait. Data is being prepared for database insertion and Product Details')
    time.sleep(5)

    print(f"Saving product links to {product_cards_filename}")
    with open(product_cards_filename, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        for link in Product_Links:
            writer.writerow([link])

print('reading CSV')

# Read existing product_links from product_cards.csv
with open(product_cards_filename, 'r', newline='', encoding='utf-8') as csvfile:
    reader = csv.reader(csvfile)
    for row in reader:
        Product_Links.append(row[0])
    
    # Load unique links into a set
    product_links = set(row[0] for row in reader if row)
    
with tqdm(total=len(Product_Links), desc="Storing product information in the database.") as pbar2:
    for pro_link in Product_Links:
        productName = ""
        productsubtitle = ""
        productprice = ""
        ProductBrand = ""
        product_description = ""
        product_instructions = ""
        category_name_list = []
        image_list = []
        productEAN = ''
        Size = ''
        rating = ''
        sites_id = get_sites_id(pro_link)
        link = ''

        response = requests.get(pro_link)
        if response.status_code == 200:

            soup = BeautifulSoup(response.content, 'html.parser')

            # Main_div = soup.find('div',class_='a0 a1 as m fn au av ei g4 g5 g6 g7')
            Main_div = soup.find('div',id='content-container')
            Main_Tab_div = soup.find('div', id='product-tabs')

            #Name
            try:
                productName = Main_div.find('h1').text
            except:
                pass
            
            #Price
            try:
                productprice =  re.search(r'\d+', Main_div.find_all('span')[1].text).group()
            except:
                pass

            #Brand
            try:
                ProductBrand = Main_div.find('h3').text
            except:
                pass  

            ProductBrand = ProductBrand.strip()
            
            #Images
            try:
                Productimages = Main_div.find_all('img')
            except:
                pass 

            #Description
            try:
                product_description =  Main_Tab_div.find('div', class_='bg bh').text.replace('Beskrivning','')
            except:
                pass     

            try:
                tab1_div =  Main_Tab_div.find('div', id='tab1')
            except:
                pass
            
            try:
                tab2_div =  Main_Tab_div.find('div', id='tab2')
            except:
                pass
            
            try:
                tab3_div =  Main_Tab_div.find('div', id='tab3')
            except:
                pass


            # Find Instruction
            try:
                tab1_heading = tab1_div.find('h3').text
                if tab1_heading:
                    if tab1_heading == 'Innehåll':
                        product_instructions =  tab1_div.text.replace('Innehåll','')
            except:
                pass


            # try to find the product EAN NUMBER AND CATEGORY
            try:
                tab2_heading = tab2_div.find('h3').text
                if tab2_heading:
                    if tab2_heading == 'Fakta':
                        category_fatch_div  =  tab2_div.find_all('a')
                        separate_fetch_p = tab2_div.find_all('p')
            except:
                pass
            # try to find the product EAN NUMBER AND CATEGORY
            try:
                tab3_heading = tab3_div.find('h3').text
                if tab3_heading == 'Fakta':
                    category_fatch_div  =  tab3_div.find_all('a')
                    separate_fetch_p = tab3_div.find_all('p')
            except:
                pass


            if separate_fetch_p:
                for index, p_tag in enumerate(separate_fetch_p):
                    if 'Artikelnummer' == p_tag.text:
                        productEAN = separate_fetch_p[index + 1].text
                        if len(productEAN) >= 12 and productEAN[0] == '0':
                            productEAN = productEAN[1:]  # Remove the leading '0'
                            #print("Adjusted EAN Number:", productEAN)
                    if 'storlek' in p_tag.text:
                        Size = separate_fetch_p[index + 1].text

            # Load the category assignment CSV file
            category_assignment_df = pd.read_csv('category_assignments.csv')

            # Assuming category_fatch_div is a list of elements containing category names
            if category_fatch_div:
                for cat_name in category_fatch_div:
                    category_name = cat_name.text.strip()
                    category_name_list.append(category_name)
                    
                    # Check if the category name exists in the CSV file
                    if category_name in category_assignment_df['CategoryName'].values:
                        # Get the parent category value for the matched category name
                        parent_category = category_assignment_df.loc[
                            category_assignment_df['CategoryName'] == category_name, 'ParentCategory'].iloc[0]
                        # Assign the parent category value to the scraped category
                        # You can add this value to a dictionary with the category name as key
                        # or create a new column in your DataFrame if you are storing the data there
                        # For demonstration, let's print the values
                        print(f"Category: {category_name}, Parent Category: {parent_category}")
            else:
                category_name_list = []


            if Productimages:
                for img_path in Productimages:
                    path = img_path.get('src')
                    if path:
                        full_path = Base_URL + str(path)
                        image_list.append(full_path)
            

            link = pro_link


            # print(f'productEAN\n {productEAN}')
            # print(f'productName\n {productName}')
            # print(f'productsubtitle\n {productsubtitle}')
            # print(f'productprice\n {productprice}')
            # print(f'ProductBrand\n {ProductBrand}')
            # print(f'product_description\n {product_description}')
            # print(f'product_instructions\n {product_instructions}')
            # print(f'category_name_list\n {category_name_list}')
            # print(f'image_list\n {image_list}')
            # print(f'Size\n {Size}')
            # print(f'rating\n {rating}')
            # print(f'sites_id\n {sites_id}')


            time.sleep(1)
            DatabaseObj = DatabaseFunction()
            DatabaseObj.insertion(productName,productsubtitle, productprice, ProductBrand, product_description , product_instructions, category_name_list, image_list, productEAN, Size, rating,sites_id, formatted_datetime, link)
        pbar2.update(1)