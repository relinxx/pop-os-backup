import requests
from bs4 import BeautifulSoup
import time
import re
from urllib.parse import urljoin, urlparse
import csv
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException, StaleElementReferenceException
from datetime import datetime
from DatabaseFunction import DatabaseFunction, get_sites_id
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains

# Get the current date and time
current_datetime = datetime.now()
f_datetime = current_datetime.strftime("%Y-%m-%d %H:%M:%S")
#print("Scraping Started at :",f_datetime)

def load_more():
    try:
        while True:
            load_more_button = WebDriverWait(driver, 20).until(
                EC.element_to_be_clickable((By.XPATH, '//div[@class="row loadMore text-center"]/div/a[contains(text(), "+ Visa fler")]'))
            )
            load_more_button.click()
            time.sleep(3)
    except StaleElementReferenceException:
        print("Button is no longer clickable. Stopping.")
    except Exception as e:
        print(f"Error: {e}")
        
# Function to check if the page is invalid based on the presence of certain elements/classes
def is_invalid_page(driver):
    try:
        # Check for breadcrumb indicating "Ogiltig adress"
        breadcrumb = driver.find_element(By.XPATH, '//ul[@class="breadcrumb"]/li/span[contains(@class, "current") and text()="Ogiltig adress"]')
        return True
    
    except NoSuchElementException:
        pass
    try:
        # Check for the mainContent div containing a specific image
        main_content_div = driver.find_element(By.XPATH, '//div[@class="col-md-12 mainContent"]/p/a/img[contains(@src, "/globalassets/404-banner/404_sidan_siten_1280x350px.jpg")]')
        return True
    
    except NoSuchElementException:
        pass
    return False

def cookie_button():
    try:
        wait = WebDriverWait(driver, 2)
        button_xpath = '//*[@id="onetrust-accept-btn-handler"]'
        popup_button = wait.until(EC.element_to_be_clickable((By.XPATH, button_xpath)))
        if popup_button:
            popup_button.click()
    except TimeoutException:
        print("Popup did not appear within the specified timeout.")
    except Exception as e:
        print(f"Error handling modal: {e}")
        
def discount_button():
    try:
        wait = WebDriverWait(driver, 5)
        text_to_check = "Kampanjer just nu - upp till 30% rabatt"
        button_xpath = '//*[@id="__next"]/div[2]/div/div/button'
        
        # Wait for the text to be present in the page
        wait.until(EC.text_to_be_present_in_element((By.CSS_SELECTOR, ".MuiTypography-footnote"), text_to_check))
        
        # Once text is present, click the button
        popup_button = wait.until(EC.element_to_be_clickable((By.XPATH, button_xpath)))
        if popup_button:
            popup_button.click()
    except TimeoutException:
        print("Text or button did not appear within the specified timeout.")
    except Exception as e:
        print(f"Error handling modal: {e}")
        
def scroll_down(driver, pixels=100):
    script = f"window.scrollBy(0, {pixels});"
    driver.execute_script(script)
    
def extract_size(product_name):
    # Define regular expressions for different size patterns
    size_patterns = [
        r'(?i)\b(?:Vit|Grå|Black|White)\b\s*(\d+\s*[a-zA-Z]+[-\s]*[a-zA-Z]*)$',  
        r'(\d+\s*[a-zA-Z]+[-\s]*[a-zA-Z]*)$',  
        r'([a-zA-Z]+[-\s]*\d+[-\s]*[a-zA-Z]*)$',  
    ]
    
    # Try to find a matching size pattern in the product name
    for pattern in size_patterns:
        match = re.search(pattern, product_name)
        if match:
            return match.group(1).strip()
        
    # Return None if no size pattern is found
    return None

def scrape_price(url):
    # Make a request to the URL
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Check for Kampanjpris
    kampanjpris_price = get_price_for_label(soup, 'Kampanjpris')
    
    if kampanjpris_price:
        return kampanjpris_price
    
    # Check for Klubbpris
    klubpris_price = get_price_for_label(soup, 'Klubbpris')
    
    if klubpris_price:
        return klubpris_price
    
    # If not Kampanjpris or Klubbpris, check for Webbpris
    webbpris_price = get_price_for_label(soup, 'Webbpris')
    return webbpris_price

def get_price_for_label(soup, label):
    # Find the element with the specified label
    label_element = soup.find('p', string=label)
    
    if label_element:
        # Get the sibling span containing the price
        price_element = label_element.find_next('span', class_='MuiTypography-root')
        if price_element:
            return price_element.string.strip()
    return None

# Set up ChromeOptions
chrome_options = webdriver.ChromeOptions()

# Add headless mode
# chrome_options.add_argument("--headless")

# Set custom user agent
user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
chrome_options.add_argument(f"user-agent={user_agent}")

# Adding driver logs 'chrome.log'
#service_args = ["--verbose", "--log-path=chrome.log"]
#chrome_options.add_argument("--enable-logging")
#chrome_options.add_argument("--disable-disk-cache")
#chrome_options.add_argument("--disable-memory-cache")
#chrome_options.add_argument("--disk-cache-dir=null")
#chrome_options.add_argument("--media-cache-size=0")
#chrome_options.add_argument("--disk-cache-size=0")
#chrome_options.add_argument("--disable-offline-load-stale-cache")
#chrome_options.add_argument("--disable-application-cache")
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--disable-extensions")
#chrome_options.add_argument("--disable-gpu")
#chrome_options.add_argument("--disable-software-rasterizer")
#chrome_options.add_argument("--disable-dev-shm-usage")
chrome_options.add_argument("--start-maximized")

prefs = {
    "profile.default_content_setting_values.images": 2,
    "profile.managed_default_content_settings.javascript": 2,
    "disk-cache-size": 4096
}

#chrome_options.add_experimental_option("prefs", prefs)

# Create Chrome webdriver instance with the specified options
#driver = webdriver.Chrome(options=chrome_options, service_args=service_args)
driver = webdriver.Chrome(options=chrome_options)
print(type(driver))

# Initialize variables
product_cards_data = []
Brand_Links = []
product_cards_filename = 'apotekhjartat.csv'
unique_links = set()  # Initialize unique links set

# Check if the product_cards.csv file exists
if os.path.exists(product_cards_filename):
    print(f"{product_cards_filename} already exists. Using existing product_links.")
    
else:
    # product_cards.csv file does not exist, continue with brand_card and product_card collection
    print(f"{product_cards_filename} does not exist. Starting brand_card and product_card collection.")
    Base_URL = "https://www.apotekhjartat.se/"
    brand_cards = "https://www.apotekhjartat.se/varumarken/"
    response = requests.get(brand_cards)
    soup = BeautifulSoup(response.content, 'html.parser')
    brand_elements = soup.select('.brandpage--list__item li a')
    
    if brand_elements:
        # Extract and print the href attribute of each link
        for brand_element in brand_elements:
            link = brand_element.get('href')
            
            if link is not None:
                full_link = urljoin(Base_URL, link)
                Brand_Links.append(full_link)
                
    else:
        print("no links")
        
    print(len(brand_elements))
    print(len(Brand_Links))
    
    '''# Scraping product links
    for brand in Brand_Links:
        driver.get(brand)
        cookie_button()
        load_more()
        page_source = driver.page_source
        
        # Use BeautifulSoup to parse the HTML
        soup = BeautifulSoup(page_source, 'html.parser')
        
        # Find all <a> tags with class "gmt-click"
        a_tags = soup.find_all('a', class_='gmt-click')
        
        # Extract and print href attributes
        for a_tag in a_tags:
            href = a_tag['href']
            if href not in unique_links:  # Check if link is unique
                product_cards_data.append([href])
                unique_links.add(href)  # Add to set of unique links
                print(href)
            
    # Save product cards to a CSV file
    if not os.path.exists(product_cards_filename):
        with open(product_cards_filename, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerows(product_cards_data)
        print(f"Product cards saved to {product_cards_filename}")'''
        
    # Initialize variables
    item_id_counter = 1
    #num_iterations = 50  # Number of iterations before restarting the driver
    batch_size = 10  # Number of brand links to process before restarting the driver
    processed_links = set()

    for i, brand in enumerate(Brand_Links):
        # Restart the driver after processing every batch_size brand links
        if i > 0 and i % batch_size == 0:
            driver.quit()
            driver = webdriver.Chrome(options=chrome_options)

        # Skip processing if the brand link has already been processed
        if brand in processed_links:
            continue

        try:
            driver.get(brand)
            cookie_button()
            load_more()
            page_source = driver.page_source

            # Use BeautifulSoup to parse the HTML
            soup = BeautifulSoup(page_source, 'html.parser')

            # Find all <a> tags with class "gmt-click"
            a_tags = soup.find_all('a', class_='gmt-click')

            # Extract and print href attributes
            for a_tag in a_tags:
                href = a_tag['href']
                if href not in unique_links:  # Check if link is unique
                    product_cards_data.append([href])
                    unique_links.add(href)  # Add to set of unique links

            # Add the processed brand link to the set
            processed_links.add(brand)

        except Exception as e:
            print(f"Error processing brand link {brand}: {e}")

    # Save product cards to a CSV file after processing all brand links
    with open(product_cards_filename, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerows(product_cards_data)
    print(f"Product cards saved to {product_cards_filename}")


#for index, product_link in enumerate(product_links[start_index:], start=start_index):

# Read existing product_links from product_cards.csv
with open(product_cards_filename, 'r', newline='', encoding='utf-8') as csvfile:
    reader = csv.reader(csvfile)
    next(reader)  # Skip the header row
    
    # Load unique links into a set
    product_links = set(row[0] for row in reader if row)

product_links = list(product_links)

# Initialize variables
item_id_counter = 1
#start_index = product_links.index('https://www.apotekhjartat.se/produkt/aco-face-anti-age-vitalising-day-cream-50-ml/')
start_item_id_counter = item_id_counter
num_iterations = 50  # Number of iterations before restarting the driver

#for index, product_link in enumerate(product_links[start_index:], start=start_index):
#while start_index < len(product_links):
for product_link in product_links:
    try:
        #product_link = product_links[start_index]  # Assign product_link here
        
        # Restart the driver after every num_iterations iterations
        if item_id_counter % num_iterations == 0:
            driver.quit()  # Close the driver
            
            # Clear browser cache and cookies
            #driver.delete_all_cookies()
            
            # Close any remaining Chrome instances (optional)
            os.system("taskkill /f /im chrome.exe")
            
            #tem_id_counter = 1
            
            # Reinitialize the driver here as per your setup
            driver = webdriver.Chrome(options=chrome_options)

            # Set the initial counter for this batch
            #start_item_id_counter = item_id_counter

        #print(f"Processing item {item_id_counter} ({start_index}/{len(product_links)}): {product_link}")
        print(f"Processing item {item_id_counter} ({len(product_links)}): {product_link}")
        
        #-------------------
        rating_text='N/A' # Reset rating_text for each new product
        driver.get(product_link)
        cookie_button()
        time.sleep(1)
        discount_button()
        link=product_link
        # Increment the counter for the next item
        item_id_counter += 1
        #start_index += 1  # Increment start_index here
        
        # Check if the page is invalid
        if is_invalid_page(driver):
            print(f"Skipping invalid page: {product_link}")
            continue
        
        #discount_button()
        
        # (1) Item IDc
        print(f"(1) Item ID: {item_id_counter}")
        
        #Main DIV
        main_div = driver.find_element(By.CLASS_NAME, 'MuiPaper-root')
        
        # (2) product name
        product_name_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, '//*[@id="__next"]/div[4]/div/div/div/div[2]/div/div[1]/div/div[1]/div[2]/div[1]/h1'))
        )
        if product_name_element:
            product_name = product_name_element.text.strip()
            print("(2) Product Name:", product_name)
        else:
            print("(2) Product name not found.")
            
        # (11) Description
        try:
            # Check if the element with the heading is present
            description_heading_element = WebDriverWait(driver, 1).until(
                EC.presence_of_element_located((By.XPATH, "//h3[contains(text(), 'Detaljerad produktbeskrivning')]"))
            )
            if description_heading_element:
                # If the element is present, extract the description using BeautifulSoup
                soup = BeautifulSoup(driver.page_source, 'html.parser')
                product_description_element = soup.find('h3', string='Detaljerad produktbeskrivning')
                if product_description_element:
                    product_description = product_description_element.find_next('span').get_text(strip=True)
                    print('(11) Description:', product_description)
                else:
                    print("Product description not found on this page.")
                    product_description = 'N/A'
            else:
                print("Description heading element not found on this page.")
                product_description = 'N/A'
        except Exception as e:
            # Handle the exception without printing it to the console
            print(f"Error scraping product description: {e}")
            product_description = 'N/A'
            
        #(3)Price
        price_element= scrape_price(product_link)

        # Extract and print the formatted price
        if price_element:
            price = price_element.replace(":-", "").replace(":", ".").strip() + " Kr"
            print("(3) Price:", price)
        else:
            print("(3) Price not found.")
            
        # (9) Image Links
        response = requests.get(product_link)
        soup = BeautifulSoup(response.text, 'html.parser')
        image_elements = soup.find_all('img')
        image_urls = [img['src'] for img in image_elements if 'www.w3.org' not in img['src']]
        
        # Create a list of valid external image URLs
        valid_image_urls = []
        for url in image_urls:
            parsed_url = urlparse(url)
            if parsed_url.netloc:  # Check if it's an absolute URL
                valid_image_urls.append(url)
                
        # Print or use the list of valid image URLs
        for i, url in enumerate(valid_image_urls, 1):
            print(f"(9) Image URL {i}: {url}")
            
        #(4)link
        link=product_link
        print("(4) link :",link)
        
        # Get the product name
        product_name = driver.find_element(By.XPATH, '//*[@id="__next"]/div[4]/div/div/div/div[2]/div/div[1]/div/div[1]/div[2]/div[1]/h1').text.strip()
        # Scroll down using JavaScript
        for i in range(2):  # Scroll 3 times, you can adjust the number as needed
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(1)  # Add a delay to allow the content to load
            
        # Click the button to expand the accordion
        try:
            # Wait for the presence of the button based on the text "Produktfakta"
            button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, '//h2[text()="Produktfakta"]/ancestor::div[@role="button"]'))
            )
            # Scroll into view
            actions = ActionChains(driver)
            actions.move_to_element(button).perform()
            # Click the button
            button.click()
            print("Button clicked successfully.")
        except Exception as e:
            print(f"Error clicking the button: {e}")
            
        # (5) Apotekets varuid
        apotekets_varuid_xpath = '//*[contains(h3, "Apotekets varuid")]/following-sibling::div/span[contains(@class, "MuiListItemText-primary")]'
        try:
            # Find the element next to "Apotekets varuid"
            apotekets_varuid_element = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, apotekets_varuid_xpath))
            )
            if apotekets_varuid_element:
                apotekets_varuid_number = apotekets_varuid_element.text.strip()
                print("(5) Apotekets varuid Number:", apotekets_varuid_number)
            else:
                raise NoSuchElementException
        except NoSuchElementException:
            print("Apotekets varuid element not found.")
            apotekets_varuid_number = "N/A"  # Set a default value if element not found 
            
        # (6) EAN
        ean_xpath = '//*[contains(h3, "EAN")]/following-sibling::div/span[contains(@class, "MuiListItemText-primary")]'
        try:
            # Find the element next to "EAN"
            ean_element = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, ean_xpath))
            )
            if ean_element:
                ean_number = ean_element.text.strip()
                if len(ean_number) >= 12 and ean_number[0] == '0':
                    ean_number = ean_number[1:]  # Remove the leading '0'
                    print("Adjusted EAN Number:", ean_number)
            else:
                raise NoSuchElementException
        except NoSuchElementException:
            print("EAN element not found.")
            ean_number = "N/A"  # Set a default value if element not found or text is empty
        print("(6) EAN Number:", ean_number)
        
        # Initialize an empty list to store categories
        categories_list = []
        
        import pandas as pd
        
        # Load the category assignment CSV file
        category_assignment_df = pd.read_csv('category_assignments.csv')
        
        # (7) Categories
        #kategori_xpath = '//*[contains(h3, "Kategori")]/following-sibling::div/span/a[contains(@class, "MuiTypography-inherit")]'
        #kategori_xpath = '//*[contains(h3, "Kategori")]/following-sibling::div/span[contains(@class, "MuiListItemText-primary")]/a | //*[contains(h3, "Kategori")]/following-sibling::div/span/a[contains(@class, "MuiTypography-inherit")]'
        kategori_xpath = '//*[contains(h3, "Kategori")]/following-sibling::div//a[contains(@class, "MuiTypography-inherit")]'

        try:
            # Find the elements next to "Kategori"
            kategori_elements = WebDriverWait(driver, 10).until(
                EC.presence_of_all_elements_located((By.XPATH, kategori_xpath))
            )
            if kategori_elements:
                # Extract and print the categories
                categories_list = [element.text.strip() for element in kategori_elements]
                print("(7) Categories:", categories_list)
                
                parent_categories = set()  # Set to store parent categories

                for category_name in categories_list:
                    # Check if the category name exists in the CSV file
                    if category_name in category_assignment_df['CategoryName'].values:
                        # Get the parent category value for the matched category name
                        parent_category = category_assignment_df.loc[
                            category_assignment_df['CategoryName'] == category_name, 'ParentCategory'].iloc[0]
                        # Add the parent category to the set
                        parent_categories.add(parent_category)
            else:
                raise NoSuchElementException
        except NoSuchElementException:
            print("Categories element not found.")
            categories_list = []
            parent_categories = set()

        print("(7) Categories:", categories_list)
        print("Parent Categories:", parent_categories)

        # (8) brand
        brand_xpath = '//*[contains(h3, "Varumärken")]/following-sibling::div/span/a[contains(@class, "MuiTypography-inherit")]'

        try:
            # Find the brand element next to "Varumärken"
            brand_element = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, brand_xpath))
            )
            if brand_element:
                # Extract and print the brand
                brand = brand_element.text.strip()
                print("(8) Brand:", brand)
            else:
                raise NoSuchElementException
        except NoSuchElementException:
            print("Brand element not found.")
            brand = "N/A"
            
        productName = product_name
        productsubtitle = apotekets_varuid_number
        productprice = price
        ProductBrand = brand
        product_description = product_description
        product_instructions = ''
        category_name_list = categories_list
        image_list = valid_image_urls
        productEAN = ean_number
        Size = ''
        rating = ''
        sites_id = get_sites_id(link)
        link= link
        formatted_datetime = f_datetime

        print("-------------------")  # Separator between products
        
        # Insert or update information into the MySQL database using DatabaseFunction
        DDB = DatabaseFunction()
        DDB.insertion(
            productName, productsubtitle, productprice, ProductBrand,
            product_description, product_instructions, category_name_list,
            image_list, productEAN, Size, rating, sites_id,
            formatted_datetime, link)
        print(f"This product is Added/Updated Successfully: {product_name}")
        

        # Example break condition to limit the number of processed items
        if item_id_counter - start_item_id_counter >= num_iterations:
            continue  # Continue to the next iteration of the loop
    except Exception as e:
        #print(f"Error processing product link {product_links[start_index]}: {e}")
        continue  # Continue to the next iteration of the loop

driver.quit()  # Make sure to close the driver after the loop