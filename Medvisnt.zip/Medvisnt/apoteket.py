from selenium import webdriver
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import time
import requests
import re
from urllib.parse import urljoin
import csv
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from DatabaseFunction import DatabaseFunction, get_sites_id
import os
from datetime import datetime
from selenium.common.exceptions import StaleElementReferenceException
from selenium.webdriver.common.action_chains import ActionChains


# Get the current date and time
current_datetime = datetime.now()
f_datetime = current_datetime.strftime("%Y-%m-%d %H:%M:%S")
print("Scraping Started at :",f_datetime)

# Set up Selenium webdriver with headless mode and a custom user agent
options = webdriver.ChromeOptions()
# options.add_argument("--headless")  # Add headless mode
user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
options.add_argument(f"user-agent={user_agent}")
print("Driver initialized successfully")

# Create Chrome webdriver instance with the specified options
driver = webdriver.Chrome(options=options)

# Navigate to the starting URL
Base_URL = "https://www.apoteket.se/"
brand_cards = "varumarken/"
driver.get(Base_URL+brand_cards)

product_cards_filename='apoteket.csv'
product_links=[]
product_cards_data = []
unique_item_categories = set()

# Function to handle cookie popup
def handle_cookie_popup():
    try:
        wait = WebDriverWait(driver, 5)
        # Add a more specific condition to wait for the cookie popup
        wait.until(EC.presence_of_element_located((By.ID, 'CybotCookiebotDialogBody')))
        # Locate and click the "Allow All Cookies" button
        popup_button = wait.until(EC.element_to_be_clickable((By.ID, 'CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll')))
        if popup_button:
            popup_button.click()
    except TimeoutException:
        print("Popup did not appear within the specified timeout.")
    except Exception as e:
        print(f"Error handling modal: {e}")

# Check if the product_cards.csv file exists
if os.path.exists(product_cards_filename):
    print(f"{product_cards_filename} already exists. Using existing product_links.")
    
    # Read existing product_links from product_cards.csv
    with open(product_cards_filename, 'r', newline='', encoding='utf-8') as csvfile:
        reader = csv.reader(csvfile)
        next(reader)  # Skip the header row
        product_links = [row[0] for row in reader if row]  # Skip empty rows
else:
    # product_cards.csv file does not exist, continue with brand_card and product_card collection
    print(f"{product_cards_filename} does not exist. Starting brand_card and product_card collection.")
    def load_more():
        try:
            load_more_button = driver.find_element(By.CLASS_NAME, 'button-0-2-463')  # Change the selector to the class name of the new button
            if load_more_button.is_displayed() and load_more_button.is_enabled():
                load_more_button.click()
                time.sleep(2)  # Add a delay to allow the new items to load
                return True
            else:
                return False
        except NoSuchElementException:
            return False
    while True:
            # Get the page source
            page_source = driver.page_source
            soup = BeautifulSoup(page_source, 'html.parser')

            # Find all brand cards
            brand_cards = soup.select('.content-body.editor')
            visited_brand_links = set()

            for brand_card in brand_cards:
                a_tags = brand_card.find_all('a', href=re.compile(r'/varumarken/'))

                for a_tag in a_tags:
                    relative_link = a_tag.get('href')
                    if relative_link and relative_link.startswith('/'):
                        brand_link = urljoin('https://www.apoteket.se', relative_link)

                    # Check if the brand_link has been visited before
                    if brand_link not in visited_brand_links:
                        visited_brand_links.add(brand_link)
                        print(brand_link)

                        # Find product links within the class "product-card"
                        driver.get(brand_link)
                        handle_cookie_popup()

                        # Continuously click the "Visa fler" button as long as it is clickable
                        while True:
                            try:
                                visa_fler_button = driver.find_element(By.XPATH, '//button[contains(text(), "Visa fler")]')
                                if visa_fler_button.is_displayed() and visa_fler_button.is_enabled():
                                    visa_fler_button.click()
                                    time.sleep(2)  # Add a delay to allow the new items to load
                                else:
                                    break  # Exit the loop if the button is no longer clickable
                            except NoSuchElementException:
                                break  # Exit the loop if the button is not found

                        # Find the div with id "brand-product-list"
                        try:
                            brand_product_list = driver.find_element(By.ID, 'brand-product-list')
                            print(brand_product_list)
                        except NoSuchElementException:
                            print('no product cards')
                            continue  # Skip the rest of the loop if there are no product cards

                        # Find all anchor tags within the div
                        try:
                            product_links = brand_product_list.find_elements(By.CSS_SELECTOR, 'a[class*="productLink"]')
                            # Extract and print the href attributes
                            for product_link in product_links:
                                product_href = product_link.get_attribute('href')
                                print(f"Product Href: {product_href}")
                                product_cards_data.append([product_href])

                        except NoSuchElementException:
                            print('no product cards')
                            break  # Exit the loop if there are no more product cards
                

            # Save product cards to a CSV file
            if not os.path.exists(product_cards_filename):
                with open(product_cards_filename, 'w', newline='', encoding='utf-8') as csvfile:
                    writer = csv.writer(csvfile)
                    writer.writerows(product_cards_data)
                print(f"Product cards saved to {product_cards_filename}")
                print(len(product_links))
                #driver.quit()
item_id_counter=1
start_index = product_links.index('https://www.apoteket.se/produkt/omron-m4-intelli-it-1-st-lada-1120997/') +1
for product_link in product_links[start_index:]:
#for product_link in product_links:
    driver.get(product_link)
    handle_cookie_popup()
    
    # Check if the driver is redirected to an undesired URL
    if 'https://www.apoteket.se/kategori/' in driver.current_url:
        print(f"Skipped processing for redirected URL: {driver.current_url}")
        continue
    
    link=product_link
    time.sleep(5)
    # Find the main div
    main_div = driver.find_element(By.ID, 'apoteket-body')

    # Find the product name (h1 tag)
    product_name = main_div.find_element(By.XPATH, '//h1[contains(@class, "title-")]').text
    # Capitalize the first letter of the sentence
    product_name = product_name.capitalize()
    # Remove "-" from the product_name
    product_name = product_name.replace('-', ' ')

    # Find the product description (p tag)
    try:
        sub_title_element = main_div.find_element(By.XPATH, '//p[contains(@class, "description-")]')
        sub_title = sub_title_element.text
    except NoSuchElementException:
        sub_title = "no sub_title"

    # Find all paragraphs within the main div
    paragraphs = main_div.find_elements(By.XPATH, '//p[not(contains(@class, "title-")) and not(contains(@class, "description-"))]')
    # Extract text content from each paragraph
    paragraph_texts = [re.sub(r'[^\w\s]', '', paragraph.text) for paragraph in paragraphs if paragraph.text.strip()]

    product_description_str = '\n'.join(paragraph_texts)
    
    # Find the price (div tag)
    price = main_div.find_element(By.XPATH, '//div[contains(@class, "price-")]').text

    # Find the button and move to it before clicking
    button_selector = '//button[@data-cy="tab" and .//span[contains(@class, "tabName") and text()="Produktfakta"]]'
    button = driver.find_element(By.XPATH, button_selector)

    # Use ActionChains to move to the element before clicking
    ActionChains(driver).move_to_element(button).click().perform()
    
    # Wait for the content to load
    content_locator = (By.ID, 'Produktinformation-1-content')
    try:
        wait_for_content = WebDriverWait(driver, 5).until(EC.presence_of_element_located(content_locator))
    except TimeoutException:
        print("Timed out waiting for content to load.")
        # Handle the timeout exception here, for example, you can log the error or take appropriate action.
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

    time.sleep(2)

    # Extract additional information
    #brand
    try:
        brand_element = driver.find_element(By.XPATH, '//div[contains(text(), "Varumärke:")]/a')
        brand = brand_element.text
    except NoSuchElementException:
        brand = "no brand"
    brand = brand.strip()
    
    #category
    category_elements = driver.find_elements(By.XPATH, '//div[contains(text(), "Kategori:")]/div/a')
    categories = [element.text for element in category_elements]

    import pandas as pd

    # Load the category assignment CSV file
    category_assignment_df = pd.read_csv('category_assignments.csv')

    # Assuming category_elements is a list of elements containing category names
    categories = [element.text for element in category_elements]

    # Remove the word "Kategori" from each category
    categories = [category.replace('Kategori / ', '') for category in categories]

    # Convert the list to a set to ensure uniqueness
    unique_categories_set = set(categories)

    # Convert the set back to a list if needed
    unique_categories_list = list(unique_categories_set)

    # Assign parent categories based on the CSV file
    parent_categories = set()
    for category_name in unique_categories_list:
        # Check if the category name exists in the CSV file
        if category_name in category_assignment_df['CategoryName'].values:
            # Get the parent category value for the matched category name
            parent_category = category_assignment_df.loc[
                category_assignment_df['CategoryName'] == category_name, 'ParentCategory'].iloc[0]
            # Add the parent category to the set
            parent_categories.add(parent_category)

    # Convert the list to a comma-separated string
    categories_str = ', '.join(unique_categories_list)

    # Print or save the resulting string
    print("Unique Categories:", unique_categories_list)
    print("Parent Categories:", parent_categories)


    # Item ID
    print(f"Item ID: {item_id_counter}")
    item_id_counter += 1  # Increment the counter for the next item
    # Print or save the resulting string
    ean_element = driver.find_element(By.XPATH, '//div[contains(text(), "Förpackningsstorlek:")]/following-sibling::div')
    item_id_element = driver.find_element(By.XPATH, '//div[contains(text(), "EAN:")]/following-sibling::div')
    #varunummer = driver.find_element(By.XPATH, '//div[contains(text(), "Varunummer:")]/following-sibling::div').text

    # Extract only numeric values using regular expressions
    ean = re.sub(r'\D', '', ean_element.text)
    if len(ean) >= 12 and ean[0] == '0':
        ean = ean[1:]  # Remove the leading '0'
        print("Adjusted EAN Number:", ean)

    item_id = re.sub(r'\D', '', item_id_element.text)


    # Set a default value for image_link
    image_link = "no image found"

    # Try to find the image within a button
    try:
        #within a div
        image_locator = (By.XPATH, '//*[@id="product-page-root"]/div[1]/div[2]/div[1]/div[2]//img')
        wait_for_image = WebDriverWait(driver, 10).until(EC.presence_of_element_located(image_locator))

        # Find the image element directly within the div
        image_element = driver.find_element(*image_locator)

        # Get the source attribute of the image element (image link)
        image_link = image_element.get_attribute("src")
        


    # Catch TimeoutException when the image is not found within the button
    except TimeoutException:
        try:
            # Find the image element within the button using XPath
            image_locator = (By.XPATH, '//*[@id="product-page-root"]/div[1]/div[2]/div[1]/div[2]/button/img')
            wait_for_image = WebDriverWait(driver, 10).until(EC.presence_of_element_located(image_locator))

            # Find the button element
            button_element = driver.find_element(*image_locator)

            # Check if the image element is present within the button
            try:
                image_element = button_element.find_element(By.TAG_NAME, 'img')

                # Get the source attribute of the image element (image link)
                image_link = image_element.get_attribute("src")

            # Handle the case where the image element is not found within the button
            except NoSuchElementException:
                print("No image found within the button")

        # Catch TimeoutException again when the image is not found
        except TimeoutException:
            # If the image is still not found, no need to raise an exception, just print a message
            print("No image found")

    # Check if the default value is still present
    if image_link == "no image found":
        print("No image found")
    else:
        print(f"Image Link: {image_link}")

        
    # Find the div containing "Förpackningsstorlek" and retrieve the text content
    forpackningsstorlek_element = driver.find_element(By.XPATH, '//div[contains(text(), "Förpackningsstorlek")]')

    # Get the text content of the same div
    forpackningsstorlek_text = forpackningsstorlek_element.text

    # Remove redundant text and print the result
    forpackningsstorlek_text = forpackningsstorlek_text.replace("Förpackningsstorlek:", "").strip()
    print("size", forpackningsstorlek_text)

    # Print the scraped information
    print("Image Link:", image_link)
    print("Product Name:", product_name)
    print(sub_title)
    print("Description",paragraph_texts)
    print("des_test",product_description_str)
    print("Price:", price)
    print(brand)
    print("Kategori:", parent_categories)
    print( ean)
    print(item_id)
    print(link)
    
    productName = product_name
    productsubtitle = item_id
    productprice = price
    ProductBrand = brand
    product_description = product_description_str
    product_instructions = sub_title
    category_name_list = parent_categories
    image_list = [image_link]
    productEAN = ean
    Size = forpackningsstorlek_text
    rating = 'N/A'
    sites_id = get_sites_id(link)
    link= link
    formatted_datetime = f_datetime

    print("------------")  # Separator between products
    # Insert or update information into the MySQL database using DatabaseFunction
    DDB = DatabaseFunction()
    DDB.insertion(
    productName, productsubtitle, productprice, ProductBrand,
    product_description, product_instructions, category_name_list,
    image_list, productEAN, Size, rating, sites_id,
    formatted_datetime, link)
    print(f"This product is Added/Updated Successfully: {product_name}")
    
# Close the browser when done
driver.quit()
# Print the product links and their length
print("Number of product links:", len(product_links))

