from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

# Set up ChromeOptions
chrome_options = webdriver.ChromeOptions()

# Add headless mode
# chrome_options.add_argument("--headless")

# Set custom user agent
user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
chrome_options.add_argument(f"user-agent={user_agent}")

#chrome_options.add_argument("--disable-application-cache")
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--disable-extensions")

# Create the Chrome driver with the configured ChromeOptions
driver = webdriver.Chrome(options=chrome_options)
driver.maximize_window()
# Navigate to the login page
driver.get('https://lpsapps.com:4499/erp/login')

wait = WebDriverWait(driver, 10)
# Find the username and password fields, and the login button, then fill in the details and submit
# Wait for the username field to become visible
username_field = wait.until(EC.visibility_of_element_located((By.NAME, "iusername")))
password_field = wait.until(EC.visibility_of_element_located((By.NAME, "password")))
login_button = wait.until(EC.element_to_be_clickable((By.XPATH, '//button[@type="submit"]')))

username_field.send_keys('abdul.hanan')
password_field.send_keys('abdul.hanan')
login_button.click()
wait.until(EC.staleness_of(login_button))
# Wait for the login process to complete (you may need to adjust the wait time based on the website)
driver.implicitly_wait(10)

driver.refresh()
# Wait for the page to load
wait.until(EC.staleness_of(login_button))

time.sleep(2) # Increased wait time

# Wait for the page to load
wait.until(EC.presence_of_element_located((By.ID, "hr_clocking")))

# Define a function to wait for an element to be clickable and enabled
def wait_for_element_to_be_clickable_and_enabled(by_locator):
    return WebDriverWait(driver, 10).until(EC.element_to_be_clickable(by_locator) and EC.visibility_of_element_located(by_locator))

# Find the check-in and check-out buttons
check_in_button_locator = (By.CSS_SELECTOR, "#hr_clocking .checkinButton")
check_out_button_locator = (By.CSS_SELECTOR, "#hr_clocking .checkoutButton")

# Check which button is enabled and click it
check_in_button = wait_for_element_to_be_clickable_and_enabled(check_in_button_locator)
check_out_button = wait_for_element_to_be_clickable_and_enabled(check_out_button_locator)

if check_in_button.is_enabled():
    check_in_button.click()
elif check_out_button.is_enabled():
    check_out_button.click()
else:
    print("Both check-in and check-out buttons are disabled.")

time.sleep(2)
# Close the browser
driver.quit()

import os

# Your existing Python script code here

# Add this line at the end of your script to shut down the system
os.system("shutdown /s /t 1")