import asyncio
from pyppeteer import launch

async def main():
    browser = await launch(headless=False)
    page = await browser.newPage()
    
    try:
        await page.goto('https://example.com')
    except Exception as e:
        print(f"An error occurred: {e}")

    
    await page.waitForSelector('input[name="iusername"]')
    await page.type('input[name="iusername"]', 'abdul.hanan')
    await page.type('input[name="password"]', 'abdul.hanan')
    await page.click('button[type="submit"]')
    
    await page.waitForNavigation()
    
    await page.waitForSelector('#hr_clocking')
    clocking_section = await page.J("#hr_clocking")
    check_in_button = await clocking_section.querySelector('.checkinButton')
    check_out_button = await clocking_section.querySelector('.checkoutButton')
    
    if await check_in_button.getProperty('disabled') == False:
        await check_in_button.click()
    elif await check_out_button.getProperty('disabled') == False:
        await check_out_button.click()
    else:
        print("Both check-in and check-out buttons are disabled.")
    
    await asyncio.sleep(2)
    
    await browser.close()

# Create and set up a new event loop
loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)

# Run the async function in the new event loop
loop.run_until_complete(main())