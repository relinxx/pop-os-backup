#!/bin/bash
streamlit run src/app.py
