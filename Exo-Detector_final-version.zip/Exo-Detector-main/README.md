# Exo-Detector
Exo-Detector  is an automated pipeline for finding potential exoplanets (planets outside our solar system) in telescope data. 
